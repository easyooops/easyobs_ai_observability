"use client";

/**
 * Auth context for the EasyObs console.
 *
 * - Stores the JWT in ``localStorage`` (see ``tokenStore`` in ``lib/api``).
 * - Hydrates the current user from ``GET /v1/auth/me`` on mount and after
 *   any sign-in / org-switch.
 * - Exposes role / current-org / accessible-services so the shell can gate
 *   menu items and pages without each route reaching for the API.
 */

import { useRouter } from "next/navigation";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import {
  fetchMe,
  selectOrg as apiSelectOrg,
  signIn as apiSignIn,
  signUp as apiSignUp,
  tokenStore,
  UnauthorizedError,
  type AuthMembership,
  type AuthOrganization,
  type AuthUser,
  type MeResponse,
  type Role,
} from "./api";

export type AuthState = {
  status: "loading" | "anonymous" | "authenticated";
  user: AuthUser | null;
  currentOrg: AuthOrganization | null;
  role: Role | null;
  approvedMemberships: AuthMembership[];
  pendingMemberships: AuthMembership[];
  accessibleServiceIds: string[] | null;
  // ``isPlatformAdmin`` is true for the bootstrapped SA *and* for any
  // approved PO of the ``administrator`` org. Use this — not ``role`` —
  // to gate management surfaces (Settings menu, OrgPicker, org create,
  // member edits in arbitrary orgs).
  isPlatformAdmin: boolean;
  // ``isPlatformMember`` is true for SA, platform admins and any approved
  // member of the administrator org (incl. DV). Such users can see every
  // other org's services in read mode.
  isPlatformMember: boolean;
  signIn: (email: string, password: string) => Promise<MeResponse>;
  signUp: (body: {
    email: string;
    password: string;
    displayName: string;
    orgId?: string;
    requestedRole?: "PO" | "DV";
  }) => Promise<MeResponse>;
  selectOrganization: (orgId: string) => Promise<MeResponse>;
  signOut: () => void;
  refresh: () => Promise<MeResponse | null>;
};

const Ctx = createContext<AuthState | null>(null);

const EMPTY_ME: MeResponse = {
  user: { id: "", email: "", displayName: "", isSuperAdmin: false },
  currentOrg: null,
  role: null,
  approvedMemberships: [],
  pendingMemberships: [],
  accessibleServiceIds: null,
  isPlatformAdmin: false,
  isPlatformMember: false,
};

function applyMe(me: MeResponse | null): Partial<AuthState> {
  if (!me) return { ...EMPTY_ME, status: "anonymous" } as Partial<AuthState>;
  const isSA = me.user?.isSuperAdmin ?? false;
  return {
    status: "authenticated",
    user: me.user,
    currentOrg: me.currentOrg,
    role: me.role,
    approvedMemberships: me.approvedMemberships,
    pendingMemberships: me.pendingMemberships,
    accessibleServiceIds: me.accessibleServiceIds,
    isPlatformAdmin: isSA || (me.isPlatformAdmin ?? false),
    isPlatformMember: isSA || (me.isPlatformMember ?? false) || (me.isPlatformAdmin ?? false),
  };
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [state, setState] = useState<AuthState>(() => ({
    ...EMPTY_ME,
    status: "loading",
    isPlatformAdmin: false,
    isPlatformMember: false,
    signIn: async () => {
      throw new Error("not ready");
    },
    signUp: async () => {
      throw new Error("not ready");
    },
    selectOrganization: async () => {
      throw new Error("not ready");
    },
    signOut: () => {},
    refresh: async () => null,
  }));

  const refresh = useCallback(async (): Promise<MeResponse | null> => {
    if (!tokenStore.get()) {
      setState((s) => ({ ...s, ...applyMe(null) }));
      return null;
    }
    try {
      const me = await fetchMe();
      setState((s) => ({ ...s, ...applyMe(me) }));
      return me;
    } catch (e) {
      if (e instanceof UnauthorizedError) {
        tokenStore.clear();
        setState((s) => ({ ...s, ...applyMe(null) }));
        return null;
      }
      throw e;
    }
  }, []);

  const signIn = useCallback(
    async (email: string, password: string) => {
      const r = await apiSignIn(email, password);
      tokenStore.set(r.token);
      const me = await refresh();
      return me ?? EMPTY_ME;
    },
    [refresh],
  );

  const signUp = useCallback(
    async (body: {
      email: string;
      password: string;
      displayName: string;
      orgId?: string;
      requestedRole?: "PO" | "DV";
    }) => {
      const r = await apiSignUp(body);
      tokenStore.set(r.token);
      const me = await refresh();
      return me ?? EMPTY_ME;
    },
    [refresh],
  );

  const selectOrganization = useCallback(
    async (orgId: string) => {
      const r = await apiSelectOrg(orgId);
      tokenStore.set(r.token);
      const me = await refresh();
      return me ?? EMPTY_ME;
    },
    [refresh],
  );

  const signOut = useCallback(() => {
    tokenStore.clear();
    setState((s) => ({ ...s, ...applyMe(null) }));
    router.replace("/signin");
  }, [router]);

  useEffect(() => {
    refresh().catch(() => undefined);
  }, [refresh]);

  // Re-sync from storage when another tab updates the token (sign-out
  // elsewhere, etc.).
  useEffect(() => {
    if (typeof window === "undefined") return;
    const onStorage = (e: StorageEvent) => {
      if (e.key === "easyobs.jwt") {
        refresh().catch(() => undefined);
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [refresh]);

  const value = useMemo<AuthState>(
    () => ({
      ...state,
      signIn,
      signUp,
      selectOrganization,
      signOut,
      refresh,
    }),
    [state, signIn, signUp, selectOrganization, signOut, refresh],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
