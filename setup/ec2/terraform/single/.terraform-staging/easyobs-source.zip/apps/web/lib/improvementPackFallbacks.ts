/**
 * Mirrors `easyobs.eval.pack_rule_presets` when the API returns no packs
 * (e.g. org not selected) so Improvement pack changes still apply presets.
 */

export type FallbackSuggested = {
  evaluatorId: string;
  weight: number;
  threshold: number;
  params: Record<string, unknown>;
};

export type FallbackPack = {
  id: string;
  label: string;
  labelI18n: { en: string; ko: string };
  suggestedRuleEvaluators: FallbackSuggested[];
  suggestedJudgeMetrics: string[];
};

const std: FallbackSuggested[] = [
  { evaluatorId: "metric.d6_concise", weight: 1, threshold: 0.6, params: {} },
  { evaluatorId: "metric.f5_fail", weight: 1, threshold: 0.7, params: {} },
  { evaluatorId: "metric.f1_e2e_lat", weight: 0.8, threshold: 0.6, params: {} },
  { evaluatorId: "metric.f4_tokens", weight: 0.8, threshold: 0.6, params: {} },
  { evaluatorId: "metric.a5_lang", weight: 0.6, threshold: 0.55, params: {} },
  { evaluatorId: "metric.f3_cost", weight: 0.8, threshold: 0.55, params: {} },
];

/** Default rule rows for a new profile (same as easyobs_standard pack). */
export function easyobsStandardEvaluators(): FallbackSuggested[] {
  return std.map((r) => ({ ...r, params: { ...r.params } }));
}

export const FALLBACK_IMPROVEMENT_PACKS: FallbackPack[] = [
  {
    id: "easyobs_standard",
    label: "EasyObs (default)",
    labelI18n: { en: "EasyObs (default)", ko: "EasyObs (기본)" },
    suggestedRuleEvaluators: std.map((r) => ({ ...r, params: { ...r.params } })),
    suggestedJudgeMetrics: ["metric.d3_faith", "metric.d1_relevance", "metric.d8_policy"],
  },
  {
    id: "easyobs_security",
    label: "Security",
    labelI18n: { en: "Security", ko: "보안" },
    suggestedRuleEvaluators: [
      { evaluatorId: "metric.d10_format", weight: 0.8, threshold: 0.55, params: {} },
      { evaluatorId: "metric.f5_fail", weight: 1, threshold: 0.65, params: {} },
      { evaluatorId: "metric.f3_cost", weight: 0.9, threshold: 0.55, params: {} },
      { evaluatorId: "metric.d6_concise", weight: 0.9, threshold: 0.55, params: {} },
    ],
    suggestedJudgeMetrics: ["metric.d8_policy", "metric.d3_faith", "metric.d12_refusal"],
  },
  {
    id: "easyobs_rag",
    label: "RAG / retrieval",
    labelI18n: { en: "RAG / retrieval", ko: "RAG·검색" },
    suggestedRuleEvaluators: [
      { evaluatorId: "metric.b1_recall", weight: 1.2, threshold: 0.6, params: {} },
      { evaluatorId: "metric.b2_precision", weight: 1, threshold: 0.55, params: {} },
      { evaluatorId: "metric.b3_mrr", weight: 0.9, threshold: 0.55, params: {} },
      { evaluatorId: "metric.f1_e2e_lat", weight: 0.7, threshold: 0.5, params: {} },
      { evaluatorId: "metric.f5_fail", weight: 1, threshold: 0.65, params: {} },
    ],
    suggestedJudgeMetrics: ["metric.d3_faith", "metric.d1_relevance", "metric.b8_coverage", "metric.c1_noise"],
  },
  {
    id: "easyobs_efficiency",
    label: "Efficiency",
    labelI18n: { en: "Efficiency", ko: "효율" },
    suggestedRuleEvaluators: [
      { evaluatorId: "metric.f1_e2e_lat", weight: 1.2, threshold: 0.6, params: {} },
      { evaluatorId: "metric.f4_tokens", weight: 1.2, threshold: 0.6, params: {} },
      { evaluatorId: "metric.f3_cost", weight: 1.2, threshold: 0.55, params: {} },
      { evaluatorId: "metric.e7_path", weight: 1, threshold: 0.55, params: {} },
      { evaluatorId: "metric.f5_fail", weight: 1, threshold: 0.65, params: {} },
    ],
    suggestedJudgeMetrics: ["metric.d1_relevance"],
  },
];
