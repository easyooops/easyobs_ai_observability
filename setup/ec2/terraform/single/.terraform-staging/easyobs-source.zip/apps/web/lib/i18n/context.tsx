"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import en from "./messages/en.json";
import ko from "./messages/ko.json";

export type AppLocale = "en" | "ko";

const STORAGE_KEY = "easyobs.uiLocale";

const CATALOG: Record<AppLocale, Record<string, unknown>> = {
  en: en as Record<string, unknown>,
  ko: ko as Record<string, unknown>,
};

function lookup(obj: unknown, path: string): string {
  const parts = path.split(".");
  let cur: unknown = obj;
  for (const p of parts) {
    if (cur == null || typeof cur !== "object") return path;
    cur = (cur as Record<string, unknown>)[p];
  }
  return typeof cur === "string" ? cur : path;
}

function getRaw(obj: unknown, path: string): unknown {
  const parts = path.split(".");
  let cur: unknown = obj;
  for (const p of parts) {
    if (cur == null || typeof cur !== "object") return undefined;
    cur = (cur as Record<string, unknown>)[p];
  }
  return cur;
}

function applyVars(template: string, vars: Record<string, string>): string {
  let out = template;
  for (const [k, v] of Object.entries(vars)) {
    out = out.split(`{${k}}`).join(v);
  }
  return out;
}

type I18nContextValue = {
  locale: AppLocale;
  setLocale: (l: AppLocale) => void;
  t: (key: string) => string;
  /** Dot-path into the active locale JSON; for arrays/objects (e.g. SDK option tables). */
  raw: (key: string) => unknown;
  /** Like `t` but replaces `{name}` placeholders in the string. */
  tsub: (key: string, vars: Record<string, string>) => string;
};

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<AppLocale>("en");

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw === "ko" || raw === "en") setLocaleState(raw);
    } catch {
      /* ignore */
    }
  }, []);

  const setLocale = useCallback((l: AppLocale) => {
    setLocaleState(l);
    try {
      window.localStorage.setItem(STORAGE_KEY, l);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale === "ko" ? "ko" : "en";
  }, [locale]);

  const t = useCallback((key: string) => lookup(CATALOG[locale], key), [locale]);

  const raw = useCallback((key: string) => getRaw(CATALOG[locale], key), [locale]);

  const tsub = useCallback(
    (key: string, vars: Record<string, string>) =>
      applyVars(lookup(CATALOG[locale], key), vars),
    [locale],
  );

  const value = useMemo(
    () => ({
      locale,
      setLocale,
      t,
      raw,
      tsub,
    }),
    [locale, setLocale, t, raw, tsub],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
