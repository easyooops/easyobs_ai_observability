"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  addGoldenItem,
  addGoldenItemFromTrace,
  autoDiscoverGoldenItems,
  createGoldenSet,
  deleteGoldenItem,
  deleteGoldenSet,
  fetchGoldenItems,
  fetchGoldenSets,
  fetchOrgServices,
  updateGoldenItemStatus,
  type GoldenLayer,
  type GoldenSet,
} from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { fmtRel } from "@/lib/format";
import { GoldenLayerLegend } from "../guides";
import { canMutateQuality, QualityGuard, ScopeBanner, WriteHint } from "../guard";
import { useI18n } from "@/lib/i18n/context";
import { GoldenHumanLabelsTab } from "./human-labels-tab";

const LAYER_OPTIONS: GoldenLayer[] = ["L1", "L2", "L3"];
const STATUS_OPTIONS = ["draft", "approved", "deprecated"] as const;

export default function GoldenPage() {
  return (
    <QualityGuard>
      <Inner />
    </QualityGuard>
  );
}

function Inner() {
  const { t } = useI18n();
  const router = useRouter();
  const search = useSearchParams();
  const labelsTab = search.get("tab") === "labels";
  const auth = useAuth();
  const orgId = auth.currentOrg?.id ?? "";
  const writable = canMutateQuality(auth);
  const qc = useQueryClient();

  const sets = useQuery({
    queryKey: ["eval", "golden-sets"],
    queryFn: fetchGoldenSets,
  });
  const services = useQuery({
    queryKey: ["org", "services", orgId],
    queryFn: () => fetchOrgServices(orgId),
    enabled: !!orgId,
  });

  const accessibleServiceIds = auth.accessibleServiceIds;
  const visibleServices = useMemo(() => {
    const all = services.data ?? [];
    if (accessibleServiceIds == null) return all;
    const allowed = new Set(accessibleServiceIds);
    return all.filter((s) => allowed.has(s.id));
  }, [services.data, accessibleServiceIds]);

  const [activeSetId, setActiveSetId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [newSet, setNewSet] = useState<{
    projectId: string | null;
    name: string;
    layer: GoldenLayer;
    description: string;
  }>({ projectId: null, name: "", layer: "L3", description: "" });
  const [error, setError] = useState<string | null>(null);

  const activeSet = useMemo(
    () => sets.data?.find((g) => g.id === activeSetId) ?? null,
    [sets.data, activeSetId],
  );

  const create = useMutation({
    mutationFn: () => {
      if (!newSet.name.trim()) throw new Error("Name is required");
      return createGoldenSet({
        projectId: newSet.projectId,
        name: newSet.name.trim(),
        layer: newSet.layer,
        description: newSet.description,
      });
    },
    onSuccess: (g) => {
      setError(null);
      setCreating(false);
      setActiveSetId(g.id);
      qc.setQueryData<GoldenSet[]>(["eval", "golden-sets"], (old) => {
        const prev = old ?? [];
        return [g, ...prev.filter((x) => x.id !== g.id)];
      });
      qc.invalidateQueries({ queryKey: ["eval", "golden-sets"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  const remove = useMutation({
    mutationFn: deleteGoldenSet,
    onSuccess: (_, id) => {
      qc.invalidateQueries({ queryKey: ["eval", "golden-sets"] });
      if (id === activeSetId) setActiveSetId(null);
    },
  });

  return (
    <>
      <div className="eo-page-head">
        <div>
          <h1 className="eo-page-title">{t("pages.golden.title")}</h1>
          <p className="eo-page-lede">{t("pages.golden.ledeDetail")}</p>
        </div>
        <div className="eo-page-meta">
          {!labelsTab && (
            <button
              type="button"
              className="eo-btn eo-btn-primary"
              onClick={() => setCreating(true)}
              disabled={!writable}
            >
              New golden set
            </button>
          )}
        </div>
      </div>
      <div className="eo-seg" style={{ marginBottom: 12, maxWidth: 480 }}>
        <button
          type="button"
          data-active={!labelsTab}
          onClick={() => router.push("/workspace/quality/golden/")}
        >
          {t("pages.golden.tabSets")}
        </button>
        <button
          type="button"
          data-active={labelsTab}
          onClick={() => router.push("/workspace/quality/golden/?tab=labels")}
        >
          {t("pages.golden.tabHumanLabels")}
        </button>
      </div>
      <ScopeBanner />
      <WriteHint />

      {labelsTab ? (
        <>
          <p className="eo-mute" style={{ fontSize: 12, marginBottom: 12, lineHeight: 1.5 }}>
            {t("pages.golden.humanLabelsBlurb")}{" "}
            <Link href="/workspace/quality/runs/" className="eo-link">
              {t("pages.golden.humanLabelsRunLink")}
            </Link>
          </p>
          <GoldenHumanLabelsTab />
        </>
      ) : (
        <>
      <GoldenLayerLegend />

      <div className="eo-grid-2" style={{ alignItems: "flex-start" }}>
        <div className="eo-card">
          <div className="eo-card-h">
            <h3 className="eo-card-title">Sets</h3>
            <span className="eo-card-sub">{sets.data?.length ?? 0} total</span>
          </div>
          <div className="eo-table-wrap">
            <table className="eo-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Layer</th>
                  <th>Service</th>
                  <th>Items</th>
                  <th>Created</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {sets.data?.length === 0 && (
                  <tr>
                    <td colSpan={6}>
                      <div className="eo-empty">No golden sets yet.</div>
                    </td>
                  </tr>
                )}
                {sets.data?.map((g) => (
                  <tr
                    key={g.id}
                    onClick={() => setActiveSetId(g.id)}
                    data-active={g.id === activeSetId}
                    style={{ cursor: "pointer" }}
                  >
                    <td className="eo-td-name">
                      <div>{g.name}</div>
                      {g.description && (
                        <div className="eo-mute" style={{ fontSize: 11 }}>
                          {g.description}
                        </div>
                      )}
                    </td>
                    <td>
                      <span className="eo-tag eo-tag-accent">{g.layer}</span>
                    </td>
                    <td className="mono">
                      {g.projectId
                        ? services.data?.find((s) => s.id === g.projectId)?.name ??
                          g.projectId.slice(0, 8)
                        : "—"}
                    </td>
                    <td className="mono">{g.itemCount}</td>
                    <td>{fmtRel(g.createdAt)}</td>
                    <td>
                      {writable && (
                        <button
                          type="button"
                          className="eo-btn eo-btn-ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`Delete golden set "${g.name}"?`)) {
                              remove.mutate(g.id);
                            }
                          }}
                          disabled={remove.isPending}
                        >
                          Delete
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="eo-card">
          <div className="eo-card-h">
            <h3 className="eo-card-title">
              {activeSetId ? activeSet?.name ?? "Items" : "Items"}
            </h3>
          </div>
          {!activeSetId && (
            <div className="eo-empty">Select a set on the left.</div>
          )}
          {activeSetId && !activeSet && (
            <div className="eo-empty">Loading set…</div>
          )}
          {activeSetId && activeSet && (
            <SetItems set={activeSet} writable={writable} />
          )}
        </div>
      </div>

      {creating && (
        <div className="eo-card" style={{ marginTop: 12 }}>
          <div className="eo-card-h">
            <h3 className="eo-card-title">New golden set</h3>
          </div>
          <div className="eo-grid-3" style={{ gap: 12 }}>
            <label className="eo-field">
              <span>Name</span>
              <input
                value={newSet.name}
                onChange={(e) => setNewSet({ ...newSet, name: e.target.value })}
              />
            </label>
            <label className="eo-field">
              <span>Layer</span>
              <select
                value={newSet.layer}
                onChange={(e) =>
                  setNewSet({ ...newSet, layer: e.target.value as GoldenLayer })
                }
              >
                {LAYER_OPTIONS.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </label>
            <label className="eo-field">
              <span>Service</span>
              <select
                value={newSet.projectId ?? ""}
                onChange={(e) =>
                  setNewSet({ ...newSet, projectId: e.target.value || null })
                }
              >
                <option value="">All services</option>
                {visibleServices.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <label className="eo-field">
            <span>Description</span>
            <input
              value={newSet.description}
              onChange={(e) =>
                setNewSet({ ...newSet, description: e.target.value })
              }
            />
          </label>
          {error && (
            <div className="eo-empty" style={{ color: "var(--eo-err)" }}>
              {error}
            </div>
          )}
          <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
            <button
              type="button"
              className="eo-btn eo-btn-ghost"
              onClick={() => setCreating(false)}
            >
              Cancel
            </button>
            <button
              type="button"
              className="eo-btn eo-btn-primary"
              onClick={() => create.mutate()}
              disabled={create.isPending || !writable}
            >
              {create.isPending ? "Creating…" : "Create"}
            </button>
          </div>
        </div>
      )}
        </>
      )}
    </>
  );
}

function SetItems({ set: g, writable }: { set: GoldenSet; writable: boolean }) {
  const qc = useQueryClient();
  const items = useQuery({
    queryKey: ["eval", "golden-items", g.id],
    queryFn: () => fetchGoldenItems(g.id),
  });

  const [manualJson, setManualJson] = useState("");
  const [traceId, setTraceId] = useState("");
  const [autoSize, setAutoSize] = useState(20);
  const [error, setError] = useState<string | null>(null);

  const addManual = useMutation({
    mutationFn: () => {
      let payload: Record<string, unknown>;
      try {
        payload = JSON.parse(manualJson);
      } catch {
        throw new Error("Payload must be valid JSON");
      }
      return addGoldenItem(g.id, payload);
    },
    onSuccess: () => {
      setManualJson("");
      setError(null);
      qc.invalidateQueries({ queryKey: ["eval", "golden-items", g.id] });
      qc.invalidateQueries({ queryKey: ["eval", "golden-sets"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  const addFromTrace = useMutation({
    mutationFn: () => {
      if (!traceId) throw new Error("Trace id required");
      return addGoldenItemFromTrace(g.id, { traceId });
    },
    onSuccess: () => {
      setTraceId("");
      setError(null);
      qc.invalidateQueries({ queryKey: ["eval", "golden-items", g.id] });
      qc.invalidateQueries({ queryKey: ["eval", "golden-sets"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  const auto = useMutation({
    mutationFn: () => {
      if (!g.projectId)
        throw new Error("Auto-discover requires a project-scoped set");
      return autoDiscoverGoldenItems(g.id, {
        projectId: g.projectId,
        sampleSize: autoSize,
      });
    },
    onSuccess: () => {
      setError(null);
      qc.invalidateQueries({ queryKey: ["eval", "golden-items", g.id] });
      qc.invalidateQueries({ queryKey: ["eval", "golden-sets"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  const setStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      updateGoldenItemStatus(id, status),
    onSuccess: () =>
      qc.invalidateQueries({ queryKey: ["eval", "golden-items", g.id] }),
  });
  const removeItem = useMutation({
    mutationFn: deleteGoldenItem,
    onSuccess: () =>
      qc.invalidateQueries({ queryKey: ["eval", "golden-items", g.id] }),
  });

  return (
    <>
      {writable && (
        <div className="eo-grid-3" style={{ gap: 8 }}>
          <div>
            <div className="eo-card-sub">Manual</div>
            <textarea
              rows={3}
              value={manualJson}
              onChange={(e) => setManualJson(e.target.value)}
              placeholder='{"query":"...","expected":"..."}'
              style={{ width: "100%", fontFamily: "var(--eo-mono)", fontSize: 11 }}
            />
            <button
              type="button"
              className="eo-btn"
              onClick={() => addManual.mutate()}
              disabled={addManual.isPending}
            >
              Add manual
            </button>
          </div>
          <div>
            <div className="eo-card-sub">From trace</div>
            <input
              value={traceId}
              onChange={(e) => setTraceId(e.target.value)}
              placeholder="trace_id"
              style={{ width: "100%" }}
            />
            <button
              type="button"
              className="eo-btn"
              onClick={() => addFromTrace.mutate()}
              disabled={addFromTrace.isPending}
              style={{ marginTop: 6 }}
            >
              Add from trace
            </button>
          </div>
          <div>
            <div className="eo-card-sub">Auto-discover</div>
            <input
              type="number"
              value={autoSize}
              min={1}
              max={200}
              onChange={(e) =>
                setAutoSize(Number.parseInt(e.target.value || "0", 10) || 0)
              }
              style={{ width: "100%" }}
              disabled={!g.projectId}
            />
            <button
              type="button"
              className="eo-btn"
              onClick={() => auto.mutate()}
              disabled={auto.isPending || !g.projectId}
              style={{ marginTop: 6 }}
              title={
                g.projectId ? "" : "Auto-discover requires a project-scoped set"
              }
            >
              Sample {autoSize}
            </button>
          </div>
        </div>
      )}
      {error && (
        <div className="eo-empty" style={{ color: "var(--eo-err)" }}>
          {error}
        </div>
      )}

      <div className="eo-divider" style={{ margin: "10px 0" }} />
      <div className="eo-table-wrap" style={{ maxHeight: 360, overflow: "auto" }}>
        <table className="eo-table">
          <thead>
            <tr>
              <th>Layer</th>
              <th>Source</th>
              <th>Status</th>
              <th>Trace</th>
              <th>Created</th>
              <th>Payload</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {items.data?.length === 0 && (
              <tr>
                <td colSpan={7}>
                  <div className="eo-empty">No items yet.</div>
                </td>
              </tr>
            )}
            {items.data?.map((it) => (
              <tr key={it.id}>
                <td className="mono">{it.layer}</td>
                <td className="mono">{it.sourceKind}</td>
                <td>
                  {writable ? (
                    <select
                      value={it.status}
                      onChange={(e) =>
                        setStatus.mutate({ id: it.id, status: e.target.value })
                      }
                    >
                      {STATUS_OPTIONS.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span>{it.status}</span>
                  )}
                </td>
                <td className="mono">
                  {it.sourceTraceId?.slice(0, 12) ?? "—"}
                </td>
                <td>{fmtRel(it.createdAt)}</td>
                <td>
                  <code style={{ fontSize: 10 }}>
                    {JSON.stringify(it.payload).slice(0, 80)}
                  </code>
                </td>
                <td>
                  {writable && (
                    <button
                      type="button"
                      className="eo-btn eo-btn-ghost"
                      onClick={() => {
                        if (confirm("Remove this item?")) {
                          removeItem.mutate(it.id);
                        }
                      }}
                    >
                      ×
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
