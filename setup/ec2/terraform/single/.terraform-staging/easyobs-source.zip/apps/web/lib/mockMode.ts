/**
 * Mirrors backend `EASYOBS_SEED_MOCK_DATA` for UI defaults (Judge register form, etc.).
 * Set `NEXT_PUBLIC_EASYOBS_SEED_MOCK_DATA=true` in apps/web `.env` when the API uses mock seeding.
 */
export function isSeedMockDataMode(): boolean {
  return process.env.NEXT_PUBLIC_EASYOBS_SEED_MOCK_DATA === "true";
}
