"use client";

import { useSearchParams, useRouter } from "next/navigation";
import { Fragment, Suspense, useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { rangeKey, resolveRange, useWorkspace, windowLabel } from "@/lib/context";
import {
  createEvalRun,
  estimateEvalRun,
  fetchEvalProfiles,
  fetchEvalResults,
  fetchEvalRun,
  fetchEvalRuns,
  fetchGoldenSets,
  fetchTraces,
  fetchJudgeModels,
  type EvalProfile,
  type EvalResult,
  type EvalRun,
  type EvalRunMode,
  type HumanLabelIn,
  type RunEstimate,
  type TraceListItem,
} from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { fmtInt, fmtPct, fmtPrice, fmtRel, fmtScore, truncate } from "@/lib/format";
import { canMutateQuality, QualityGuard, ScopeBanner, WriteHint } from "../guard";
import { useI18n } from "@/lib/i18n/context";

export default function RunsPage() {
  return (
    <QualityGuard>
      <Suspense fallback={<div className="eo-empty">Loading runs…</div>}>
        <Inner />
      </Suspense>
    </QualityGuard>
  );
}

function Inner() {
  const { t, locale } = useI18n();
  const auth = useAuth();
  const orgId = auth.currentOrg?.id ?? "";
  const writable = canMutateQuality(auth);
  const ws = useWorkspace();
  const search = useSearchParams();
  const router = useRouter();
  const qc = useQueryClient();
  const range = resolveRange(ws);
  const rk = rangeKey(ws);

  const [selectedRunId, setSelectedRunId] = useState<string | null>(
    search.get("run"),
  );

  useEffect(() => {
    setSelectedRunId(search.get("run"));
  }, [search]);

  const profiles = useQuery({
    queryKey: ["eval", "profiles"],
    queryFn: () => fetchEvalProfiles(true),
  });
  const runs = useQuery({
    queryKey: ["eval", "runs"],
    queryFn: () => fetchEvalRuns(100),
    refetchInterval: 10_000,
  });
  const traces = useQuery({
    queryKey: ["traces", "for-eval", rk],
    queryFn: () => fetchTraces(range, { limit: 2000, withLlm: true }),
    staleTime: 30_000,
  });
  const goldenSets = useQuery({
    queryKey: ["eval", "golden-sets"],
    queryFn: fetchGoldenSets,
    enabled: !!orgId,
  });
  const judgeModelsReg = useQuery({
    queryKey: ["eval", "judges", "all"],
    queryFn: () => fetchJudgeModels(true),
    enabled: !!orgId,
  });
  const hasOrgJudges = useMemo(
    () => (judgeModelsReg.data ?? []).some((j) => j.enabled),
    [judgeModelsReg.data],
  );

  const profileFromQuery = search.get("profile");
  const [profileId, setProfileId] = useState<string>(profileFromQuery ?? "");
  useEffect(() => {
    if (profileFromQuery) setProfileId(profileFromQuery);
  }, [profileFromQuery]);

  const [pickedTraceIds, setPickedTraceIds] = useState<Record<string, boolean>>(
    {},
  );
  /** Sessions listed here have their trace rows collapsed (default: all expanded). */
  const [collapsedSessions, setCollapsedSessions] = useState<Set<string>>(
    () => new Set(),
  );
  const [notes, setNotes] = useState("");
  const [runMode, setRunMode] = useState<EvalRunMode>("trace");
  const [goldenSetId, setGoldenSetId] = useState("");
  const [humanLabelsJson, setHumanLabelsJson] = useState("");
  const [estimate, setEstimate] = useState<RunEstimate | null>(null);
  const [error, setError] = useState<string | null>(null);

  const selectedProfile = useMemo<EvalProfile | undefined>(
    () => profiles.data?.find((p) => p.id === profileId),
    [profiles.data, profileId],
  );

  const selectedTraceIds = Object.keys(pickedTraceIds).filter(
    (k) => pickedTraceIds[k],
  );

  const estimateRun = useMutation({
    mutationFn: () =>
      estimateEvalRun({
        profileId,
        subjectCount: Math.max(1, selectedTraceIds.length),
        projectId: selectedProfile?.projectId ?? null,
      }),
    onSuccess: (e) => {
      setEstimate(e);
      setError(null);
    },
    onError: (e: Error) => {
      setEstimate(null);
      setError(e.message);
    },
  });

  const launchRun = useMutation({
    mutationFn: () => {
      let humanLabels: HumanLabelIn[] | undefined;
      if (humanLabelsJson.trim()) {
        try {
          const parsed = JSON.parse(humanLabelsJson) as unknown;
          if (!Array.isArray(parsed)) {
            throw new Error("human labels must be a JSON array");
          }
          humanLabels = parsed
            .map((x: Record<string, unknown>) => ({
              traceId: String(x.traceId ?? x.trace_id ?? ""),
              expectedResponse: (x.expectedResponse ??
                x.expected_response ??
                null) as string | null,
              humanVerdict: (x.humanVerdict ?? x.human_verdict ?? null) as
                | string
                | null,
              notes: String(x.notes ?? ""),
            }))
            .filter((x) => x.traceId);
        } catch (e) {
          throw new Error(
            e instanceof Error ? e.message : "invalid human labels JSON",
          );
        }
      }
      return createEvalRun({
        profileId,
        projectId: selectedProfile?.projectId ?? null,
        traceIds: selectedTraceIds,
        notes,
        runMode,
        goldenSetId: goldenSetId.trim() || null,
        humanLabels,
        runContext: { uiLocale: locale },
      });
    },
    onSuccess: (run) => {
      setError(null);
      setSelectedRunId(run.id);
      router.replace(`/workspace/quality/runs/?run=${encodeURIComponent(run.id)}`);
      qc.invalidateQueries({ queryKey: ["eval", "runs"] });
      qc.invalidateQueries({ queryKey: ["quality", "overview"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  const filteredTraces = useMemo<TraceListItem[]>(() => {
    const list = traces.data ?? [];
    const projectId = selectedProfile?.projectId;
    if (!projectId) return list;
    return list.filter((t) => t.serviceId === projectId);
  }, [traces.data, selectedProfile]);

  const displayTraces = useMemo<TraceListItem[]>(() => {
    const q = ws.search.trim().toLowerCase();
    if (!q) return filteredTraces;
    return filteredTraces.filter((t) =>
      `${t.traceId} ${t.rootName} ${t.serviceName} ${t.session ?? ""} ${t.model ?? ""}`
        .toLowerCase()
        .includes(q),
    );
  }, [filteredTraces, ws.search]);

  useEffect(() => {
    const next: Record<string, boolean> = {};
    for (const t of displayTraces) next[t.traceId] = true;
    setPickedTraceIds(next);
  }, [rk, profileId, displayTraces]);

  useEffect(() => {
    if (!hasOrgJudges && runMode === "golden_judge") {
      setRunMode("trace");
    }
  }, [hasOrgJudges, runMode]);

  const tracesBySession = useMemo(() => {
    const m = new Map<string, TraceListItem[]>();
    for (const t of displayTraces) {
      const key = t.session?.trim() || "— (no session)";
      const arr = m.get(key) ?? [];
      arr.push(t);
      m.set(key, arr);
    }
    return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [displayTraces]);

  const selectAllInRange = () => {
    const next: Record<string, boolean> = {};
    for (const t of displayTraces) next[t.traceId] = true;
    setPickedTraceIds(next);
  };

  const toggleSessionExpand = (sessionKey: string) => {
    setCollapsedSessions((prev) => {
      const n = new Set(prev);
      if (n.has(sessionKey)) n.delete(sessionKey);
      else n.add(sessionKey);
      return n;
    });
  };

  const setSessionChecked = (sessionTraces: TraceListItem[], checked: boolean) => {
    setPickedTraceIds((m) => {
      const next = { ...m };
      for (const t of sessionTraces) next[t.traceId] = checked;
      return next;
    });
  };

  const clearTraceSelection = () => setPickedTraceIds({});

  return (
    <>
      <div className="eo-page-head">
        <div>
          <h1 className="eo-page-title">{t("pages.runs.title")}</h1>
          <p className="eo-page-lede">{t("pages.runs.lede")}</p>
        </div>
      </div>

      <ScopeBanner />
      <WriteHint />

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div className="eo-card">
          <div className="eo-card-h">
            <h3 className="eo-card-title">Launch</h3>
            <span className="eo-card-sub">manual judge run</span>
          </div>
          <label className="eo-field">
            <span>Profile</span>
            <select
              value={profileId}
              onChange={(e) => {
                setProfileId(e.target.value);
                setEstimate(null);
              }}
              disabled={!writable}
            >
              <option value="">— pick a profile —</option>
              {profiles.data
                ?.filter((p) => p.enabled)
                .map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                    {p.judgeModels.length === 0 ? " (rules only)" : ""}
                  </option>
                ))}
            </select>
          </label>

          <div
            className="eo-card-sub"
            style={{ marginTop: 6, display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}
          >
            <span>
              Traces in workspace window ({windowLabel(ws)}
              {selectedProfile?.projectId
                ? ` · service ${selectedProfile.projectId.slice(0, 8)}`
                : ""}
              ){ws.search.trim() ? ` · search “${ws.search.trim()}”` : ""} ·{" "}
              {displayTraces.length} shown (of {filteredTraces.length})
            </span>
            <span style={{ marginLeft: "auto", display: "flex", gap: 6, flexWrap: "wrap" }}>
              <button
                type="button"
                className="eo-btn eo-btn-ghost"
                onClick={selectAllInRange}
                disabled={!writable || displayTraces.length === 0}
              >
                Select all (visible)
              </button>
              <button
                type="button"
                className="eo-btn eo-btn-ghost"
                onClick={clearTraceSelection}
                disabled={!writable || selectedTraceIds.length === 0}
              >
                Clear
              </button>
            </span>
          </div>
          <div
            className="eo-table-wrap"
            style={{ maxHeight: 360, overflow: "auto" }}
          >
            <table className="eo-table">
              <thead>
                <tr>
                  <th />
                  <th>Session / trace</th>
                  <th>Service</th>
                  <th>Status</th>
                  <th>Started</th>
                </tr>
              </thead>
              <tbody>
                {displayTraces.length === 0 && (
                  <tr>
                    <td colSpan={5}>
                      <div className="eo-empty">
                        No traces in this window — widen the range or clear search.
                      </div>
                    </td>
                  </tr>
                )}
                {tracesBySession.map(([sessionKey, group]) => {
                  const expanded = !collapsedSessions.has(sessionKey);
                  const allOn = group.every((t) => pickedTraceIds[t.traceId]);
                  const someOn = group.some((t) => pickedTraceIds[t.traceId]);
                  return (
                    <Fragment key={sessionKey}>
                      <tr style={{ background: "var(--eo-bg-2)" }}>
                        <td>
                          <input
                            type="checkbox"
                            checked={allOn}
                            ref={(el) => {
                              if (el) el.indeterminate = !allOn && someOn;
                            }}
                            disabled={!writable}
                            onChange={(e) =>
                              setSessionChecked(group, e.target.checked)
                            }
                          />
                        </td>
                        <td colSpan={3}>
                          <button
                            type="button"
                            className="eo-btn eo-btn-ghost"
                            style={{ padding: "2px 8px", fontWeight: 600 }}
                            onClick={() => toggleSessionExpand(sessionKey)}
                          >
                            {expanded ? "▼" : "▶"} Session{" "}
                            <span className="mono">{truncate(sessionKey, 36)}</span>{" "}
                            <span className="eo-mute">({group.length})</span>
                          </button>
                        </td>
                        <td className="eo-mute" style={{ fontSize: 11 }}>
                          {expanded ? "" : "collapsed"}
                        </td>
                      </tr>
                      {expanded &&
                        group.map((t) => (
                          <tr key={t.traceId}>
                            <td>
                              <input
                                type="checkbox"
                                checked={!!pickedTraceIds[t.traceId]}
                                disabled={!writable}
                                onChange={(e) =>
                                  setPickedTraceIds((m) => ({
                                    ...m,
                                    [t.traceId]: e.target.checked,
                                  }))
                                }
                              />
                            </td>
                            <td className="mono" style={{ paddingLeft: 20 }}>
                              {t.traceId.slice(0, 12)}
                            </td>
                            <td>{t.serviceName}</td>
                            <td>
                              <span
                                className="eo-status"
                                data-tone={t.status === "ERROR" ? "err" : "ok"}
                              >
                                {t.status}
                              </span>
                            </td>
                            <td>{fmtRel(t.startedAt)}</td>
                          </tr>
                        ))}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          <label className="eo-field">
            <span>Notes</span>
            <input
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="optional run notes"
              disabled={!writable}
            />
          </label>

          <label className="eo-field">
            <span>Run mode</span>
            <select
              value={runMode}
              onChange={(e) => {
                setRunMode(e.target.value as EvalRunMode);
                if (
                  e.target.value !== "golden_gt" &&
                  e.target.value !== "golden_judge"
                ) {
                  setGoldenSetId("");
                }
              }}
              disabled={!writable}
            >
              <option value="trace">
                Trace — evaluate ingested spans (default)
              </option>
              <option value="human_label">
                Human label — expected output / verdict in JSON below
              </option>
              <option value="golden_gt">
                Golden GT — match trace to golden item; strict similarity + judge
              </option>
              <option value="golden_judge" disabled={!hasOrgJudges}>
                Golden judge — golden as reference only + judge
              </option>
            </select>
          </label>
          {!hasOrgJudges && (
            <p className="eo-mute" style={{ fontSize: 11, margin: "0 0 6px" }}>
              {t("pages.runs.noJudgesGoldenJudge")}
            </p>
          )}
          <p className="eo-mute" style={{ fontSize: 11, margin: "0 0 8px" }}>
            Call your agent API from outside EasyObs and ingest traces via OTLP. This
            screen evaluates the stored <code className="mono">trace_ids</code>.
          </p>
          {(runMode === "golden_gt" || runMode === "golden_judge") && (
            <label className="eo-field">
              <span>Golden set</span>
              <select
                value={goldenSetId}
                onChange={(e) => setGoldenSetId(e.target.value)}
                disabled={!writable}
              >
                <option value="">— select —</option>
                {(goldenSets.data ?? []).map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.layer}) · {g.itemCount} items
                  </option>
                ))}
              </select>
            </label>
          )}
          <label className="eo-field">
            <span>Human labels (JSON array, optional)</span>
            <textarea
              value={humanLabelsJson}
              onChange={(e) => setHumanLabelsJson(e.target.value)}
              rows={3}
              disabled={!writable}
              placeholder={`[{"traceId":"abc…","expectedResponse":"…","humanVerdict":"pass","notes":""}]`}
            />
          </label>

          <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
            <button
              type="button"
              className="eo-btn"
              onClick={() => estimateRun.mutate()}
              disabled={!profileId || selectedTraceIds.length === 0}
            >
              Estimate cost
            </button>
            <button
              type="button"
              className="eo-btn eo-btn-primary"
              onClick={() => launchRun.mutate()}
              disabled={
                !writable ||
                !profileId ||
                selectedTraceIds.length === 0 ||
                launchRun.isPending
              }
            >
              {launchRun.isPending
                ? "Launching…"
                : `Run on ${selectedTraceIds.length} traces`}
            </button>
          </div>

          {estimate && (
            <div
              className="eo-card"
              style={{ background: "var(--eo-bg-2)", marginTop: 8 }}
            >
              <div className="eo-card-h">
                <h3 className="eo-card-title">Estimate</h3>
              </div>
              <div className="eo-mute" style={{ fontSize: 12 }}>
                Subjects {estimate.subjectCount} · judge calls{" "}
                {estimate.judgeCalls} · projected {fmtPrice(estimate.costEstimateUsd)}
                {estimate.ruleOnly ? " · rules only" : ""}
              </div>
              <div className="eo-mute" style={{ fontSize: 12 }}>
                Monthly spent so far: {fmtPrice(estimate.monthlySpentUsd)}
              </div>
              {!estimate.costGuard.allowed && (
                <div
                  className="eo-empty"
                  style={{ color: "var(--eo-err)", marginTop: 6 }}
                >
                  Cost guard would block: {estimate.costGuard.note}
                </div>
              )}
              {estimate.costGuard.allowed && estimate.costGuard.downgrade && (
                <div
                  className="eo-empty"
                  style={{ color: "var(--eo-warn, #c89400)", marginTop: 6 }}
                >
                  Will downgrade to rules-only: {estimate.costGuard.note}
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="eo-empty" style={{ color: "var(--eo-err)" }}>
              {error}
            </div>
          )}
        </div>

        <div className="eo-card">
          <div className="eo-card-h">
            <h3 className="eo-card-title">Recent Runs</h3>
            <span className="eo-card-sub">{runs.data?.length ?? 0} runs</span>
          </div>
          <div className="eo-table-wrap" style={{ maxHeight: 480, overflow: "auto" }}>
            <table className="eo-table">
              <thead>
                <tr>
                  <th>Run</th>
                  <th>Profile</th>
                  <th>Status</th>
                  <th>Subjects</th>
                  <th>Pass</th>
                  <th>Cost</th>
                  <th>Started</th>
                </tr>
              </thead>
              <tbody>
                {runs.data?.length === 0 && (
                  <tr>
                    <td colSpan={7}>
                      <div className="eo-empty">No runs yet</div>
                    </td>
                  </tr>
                )}
                {runs.data?.map((r) => (
                  <tr
                    key={r.id}
                    onClick={() => {
                      setSelectedRunId(r.id);
                      router.replace(
                        `/workspace/quality/runs/?run=${encodeURIComponent(r.id)}`,
                      );
                    }}
                    data-active={r.id === selectedRunId}
                    style={{ cursor: "pointer" }}
                  >
                    <td className="mono">{r.id.slice(0, 8)}</td>
                    <td className="mono">{r.profileId?.slice(0, 8) ?? "—"}</td>
                    <td>
                      <RunStatusBadge run={r} />
                    </td>
                    <td className="mono">{r.subjectCount}</td>
                    <td className="mono">{fmtPct(r.passRate * 100)}</td>
                    <td className="mono">{fmtPrice(r.costActualUsd)}</td>
                    <td>{fmtRel(r.startedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {selectedRunId && <RunDetail runId={selectedRunId} />}
    </>
  );
}

function RunStatusBadge({ run }: { run: EvalRun }) {
  const tone =
    run.status === "succeeded" ? "ok" : run.status === "failed" ? "err" : "warn";
  return (
    <span className="eo-status" data-tone={tone}>
      {run.status}
    </span>
  );
}

function RunDetail({ runId }: { runId: string }) {
  const [pickedSessionKey, setPickedSessionKey] = useState<string | null>(null);

  useEffect(() => {
    setPickedSessionKey(null);
  }, [runId]);

  const run = useQuery({
    queryKey: ["eval", "run", runId],
    queryFn: () => fetchEvalRun(runId),
    refetchInterval: (q) =>
      q.state.data && q.state.data.status === "running" ? 4_000 : false,
  });
  const results = useQuery({
    queryKey: ["eval", "results", runId],
    queryFn: () => fetchEvalResults(runId, 500),
    enabled: !!runId,
  });

  const sortedResults = useMemo(() => {
    const list = results.data ?? [];
    return [...list].sort((a, b) => {
      const sa = a.sessionId ?? "";
      const sb = b.sessionId ?? "";
      if (sa !== sb) return sa.localeCompare(sb);
      return a.traceId.localeCompare(b.traceId);
    });
  }, [results.data]);

  const resultsBySession = useMemo(() => {
    const m = new Map<string, EvalResult[]>();
    for (const r of sortedResults) {
      const k = r.sessionId ?? "—";
      const arr = m.get(k) ?? [];
      arr.push(r);
      m.set(k, arr);
    }
    return [...m.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [sortedResults]);

  const detailRows = useMemo(() => {
    if (pickedSessionKey == null) return [];
    const hit = resultsBySession.find(([k]) => k === pickedSessionKey);
    return hit ? [...hit[1]].sort((a, b) => a.traceId.localeCompare(b.traceId)) : [];
  }, [pickedSessionKey, resultsBySession]);

  return (
    <div className="eo-card" style={{ marginTop: 12 }}>
      <div className="eo-card-h">
        <h3 className="eo-card-title">Run {runId.slice(0, 12)}</h3>
        <span className="eo-card-sub">
          {run.data ? run.data.status : "loading…"}
        </span>
      </div>
      {run.data && (
        <div className="eo-kpi-grid">
          <article className="eo-kpi">
            <span className="eo-kpi-label">Pass Rate</span>
            <strong className="eo-kpi-value">
              {fmtPct(run.data.passRate * 100)}
            </strong>
            <span className="eo-kpi-meta">
              {run.data.completedCount} / {run.data.subjectCount} subjects
            </span>
          </article>
          <article className="eo-kpi">
            <span className="eo-kpi-label">Avg Score</span>
            <strong className="eo-kpi-value">
              {fmtScore(run.data.avgScore)}
            </strong>
            <span className="eo-kpi-meta">
              {run.data.failedCount} failures
            </span>
          </article>
          <article className="eo-kpi" data-tone="warn">
            <span className="eo-kpi-label">Cost</span>
            <strong className="eo-kpi-value">
              {fmtPrice(run.data.costActualUsd)}
            </strong>
            <span className="eo-kpi-meta">
              est {fmtPrice(run.data.costEstimateUsd)} ·{" "}
              {fmtInt(results.data?.length ?? 0)} results
            </span>
          </article>
          <article className="eo-kpi" data-tone="ink">
            <span className="eo-kpi-label">Trigger</span>
            <strong className="eo-kpi-value" style={{ fontSize: 16 }}>
              {run.data.triggerLane}
            </strong>
            <span className="eo-kpi-meta">
              by {run.data.triggeredBy?.slice(0, 8) ?? "system"}
            </span>
          </article>
        </div>
      )}

      {run.data?.notes && (
        <div className="eo-empty" style={{ marginTop: 6 }}>
          Notes: {run.data.notes}
        </div>
      )}
      {run.data && (
        <div className="eo-mute" style={{ fontSize: 12, marginTop: 6 }}>
          Run mode: <span className="mono">{run.data.runMode ?? "trace"}</span>
          {run.data.goldenSetId ? (
            <>
              {" "}
              · golden{" "}
              <span className="mono">{run.data.goldenSetId.slice(0, 8)}</span>
            </>
          ) : null}
        </div>
      )}

      <div style={{ display: "flex", gap: 6, margin: "8px 0" }}>
        <button
          type="button"
          className="eo-btn eo-btn-ghost"
          onClick={() => downloadResults(run.data, sortedResults)}
          disabled={!sortedResults.length}
        >
          Download report (CSV)
        </button>
        <button
          type="button"
          className="eo-btn eo-btn-ghost"
          onClick={() => downloadResultsJson(run.data, sortedResults)}
          disabled={!sortedResults.length}
        >
          Download (JSON)
        </button>
      </div>

      <div className="eo-card-sub" style={{ marginTop: 8 }}>
        Sessions in this run — pick one to inspect traces below.
      </div>
      <div className="eo-table-wrap" style={{ maxHeight: 220, overflow: "auto" }}>
        <table className="eo-table">
          <thead>
            <tr>
              <th>Session</th>
              <th>Traces</th>
              <th>Pass</th>
              <th>Fail</th>
              <th>Avg score</th>
            </tr>
          </thead>
          <tbody>
            {results.isLoading && (
              <tr>
                <td colSpan={5}>
                  <div className="eo-empty">Loading results…</div>
                </td>
              </tr>
            )}
            {results.data?.length === 0 && !results.isLoading && (
              <tr>
                <td colSpan={5}>
                  <div className="eo-empty">No results recorded.</div>
                </td>
              </tr>
            )}
            {resultsBySession.map(([sessionKey, rows]) => {
              const pass = rows.filter((r) => r.verdict === "pass").length;
              const fail = rows.filter((r) => r.verdict === "fail").length;
              const avg =
                rows.reduce((s, r) => s + r.score, 0) / Math.max(rows.length, 1);
              const active = pickedSessionKey === sessionKey;
              return (
                <tr
                  key={sessionKey}
                  onClick={() => setPickedSessionKey(sessionKey)}
                  style={{ cursor: "pointer" }}
                  data-active={active}
                >
                  <td className="mono">{truncate(sessionKey, 42)}</td>
                  <td className="mono">{rows.length}</td>
                  <td className="mono">{pass}</td>
                  <td className="mono">{fail}</td>
                  <td className="mono">{fmtScore(avg)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {pickedSessionKey != null && (
        <>
          <div className="eo-card-sub" style={{ marginTop: 14 }}>
            Traces in session{" "}
            <span className="mono">{truncate(pickedSessionKey, 42)}</span>
          </div>
          <div className="eo-table-wrap" style={{ maxHeight: 420, overflow: "auto" }}>
            <table className="eo-table">
              <thead>
                <tr>
                  <th>Trace</th>
                  <th>Verdict</th>
                  <th>Score</th>
                  <th>Rule</th>
                  <th>Judge</th>
                  <th>Disagree</th>
                  <th>Cost</th>
                  <th>Findings</th>
                </tr>
              </thead>
              <tbody>
                {detailRows.map((r) => (
                  <ResultRow key={r.id} r={r} />
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function ResultRow({ r }: { r: EvalResult }) {
  const [open, setOpen] = useState(false);
  const tone =
    r.verdict === "pass" ? "ok" : r.verdict === "fail" ? "err" : "warn";
  return (
    <>
      <tr onClick={() => setOpen((v) => !v)} style={{ cursor: "pointer" }}>
        <td className="mono" onClick={(e) => e.stopPropagation()}>
          <a
            href={`/workspace/tracing/detail/?id=${encodeURIComponent(r.traceId)}`}
            className="eo-link"
          >
            {r.traceId.slice(0, 12)}
          </a>
        </td>
        <td>
          <span className="eo-status" data-tone={tone}>
            {r.verdict}
          </span>
        </td>
        <td className="mono">{fmtScore(r.score)}</td>
        <td className="mono">{fmtScore(r.ruleScore)}</td>
        <td className="mono">{r.judgeScore == null ? "—" : fmtScore(r.judgeScore)}</td>
        <td className="mono">
          {r.judgeDisagreement == null ? "—" : r.judgeDisagreement.toFixed(2)}
        </td>
        <td className="mono">{fmtPrice(r.judgeCostUsd)}</td>
        <td>{r.findings.length}</td>
      </tr>
      {open && (
        <tr>
          <td colSpan={8} style={{ background: "var(--eo-bg-2)" }}>
            <div style={{ padding: "6px 8px" }}>
              <div className="eo-card-sub">Findings</div>
              <ul style={{ margin: 0, paddingLeft: 18, fontSize: 12 }}>
                {r.findings.map((f, i) => (
                  <li key={i}>
                    <strong>{f.evaluatorId}</strong>{" "}
                    <span className="eo-mute">({f.kind})</span> ·{" "}
                    {fmtScore(f.score)} · {f.verdict} · {truncate(f.reason, 120)}
                  </li>
                ))}
              </ul>
              {Array.isArray(r.judgePerModel) && r.judgePerModel.length > 0 && (
                <>
                  <div className="eo-card-sub" style={{ marginTop: 6 }}>
                    Per-judge votes
                  </div>
                  <ul style={{ margin: 0, paddingLeft: 18, fontSize: 12 }}>
                    {(r.judgePerModel as Record<string, unknown>[]).map((v, i) => (
                      <li key={i} className="mono">
                        {JSON.stringify(v)}
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

function downloadResults(run: EvalRun | undefined, results: EvalResult[]) {
  if (!run) return;
  const header = [
    "trace_id",
    "session_id",
    "verdict",
    "score",
    "rule_score",
    "judge_score",
    "judge_disagreement",
    "judge_cost_usd",
    "findings",
  ];
  const csv = [header.join(",")].concat(
    results.map((r) =>
      [
        r.traceId,
        r.sessionId ?? "",
        r.verdict,
        r.score,
        r.ruleScore,
        r.judgeScore ?? "",
        r.judgeDisagreement ?? "",
        r.judgeCostUsd,
        `"${r.findings
          .map((f) => `${f.evaluatorId}:${f.verdict}`)
          .join(";")
          .replace(/"/g, "'")}"`,
      ].join(","),
    ),
  );
  triggerDownload(
    `eval-run-${run.id.slice(0, 8)}.csv`,
    csv.join("\n"),
    "text/csv",
  );
}

function downloadResultsJson(run: EvalRun | undefined, results: EvalResult[]) {
  if (!run) return;
  triggerDownload(
    `eval-run-${run.id.slice(0, 8)}.json`,
    JSON.stringify({ run, results }, null, 2),
    "application/json",
  );
}

function triggerDownload(name: string, body: string, mime: string) {
  const blob = new Blob([body], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}
