"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import {
  deleteHumanLabelAnnotation,
  fetchHumanLabelAnnotations,
  upsertHumanLabelAnnotation,
} from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n/context";
import { canMutateQuality } from "../guard";

/** Human review registry embedded under Golden Sets (same org scope as quality). */
export function GoldenHumanLabelsTab() {
  const { t } = useI18n();
  const auth = useAuth();
  const writable = canMutateQuality(auth);
  const search = useSearchParams();
  const qc = useQueryClient();
  const [traceId, setTraceId] = useState("");
  const [verdict, setVerdict] = useState("pass");
  const [expected, setExpected] = useState("");
  const [notes, setNotes] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    const tid = search.get("traceId") || "";
    if (tid) setTraceId(tid);
  }, [search]);

  const list = useQuery({
    queryKey: ["eval", "human-labels"],
    queryFn: () => fetchHumanLabelAnnotations(100),
  });

  const save = useMutation({
    mutationFn: () =>
      upsertHumanLabelAnnotation({
        traceId: traceId.trim(),
        expectedResponse: expected,
        humanVerdict: verdict,
        notes,
      }),
    onSuccess: () => {
      setMsg(t("pages.humanLabels.saved"));
      qc.invalidateQueries({ queryKey: ["eval", "human-labels"] });
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteHumanLabelAnnotation(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["eval", "human-labels"] }),
  });

  return (
    <div className="eo-grid-2" style={{ alignItems: "start" }}>
      <section className="eo-card">
        <div className="eo-card-h">
          <h3 className="eo-card-title">{t("pages.humanLabels.addTitle")}</h3>
        </div>
        <label className="eo-field">
          <span>{t("pages.humanLabels.traceId")}</span>
          <input
            className="eo-input"
            value={traceId}
            onChange={(e) => setTraceId(e.target.value)}
            disabled={!writable}
          />
        </label>
        <label className="eo-field">
          <span>{t("pages.humanLabels.verdict")}</span>
          <select
            className="eo-input"
            value={verdict}
            onChange={(e) => setVerdict(e.target.value)}
            disabled={!writable}
          >
            <option value="pass">pass</option>
            <option value="warn">warn</option>
            <option value="fail">fail</option>
          </select>
        </label>
        <label className="eo-field">
          <span>{t("pages.humanLabels.expected")}</span>
          <textarea
            className="eo-input"
            rows={3}
            value={expected}
            onChange={(e) => setExpected(e.target.value)}
            disabled={!writable}
          />
        </label>
        <label className="eo-field">
          <span>{t("pages.humanLabels.notes")}</span>
          <textarea
            className="eo-input"
            rows={2}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            disabled={!writable}
          />
        </label>
        {msg && (
          <p className="eo-mute" style={{ fontSize: 12 }}>
            {msg}
          </p>
        )}
        <button
          type="button"
          className="eo-btn eo-btn-primary"
          disabled={!writable || !traceId.trim() || save.isPending}
          onClick={() => {
            setMsg(null);
            save.mutate();
          }}
        >
          {save.isPending ? t("pages.humanLabels.saving") : t("pages.humanLabels.save")}
        </button>
      </section>

      <section className="eo-card">
        <div className="eo-card-h">
          <h3 className="eo-card-title">{t("pages.humanLabels.registryTitle")}</h3>
          <span className="eo-card-sub">{(list.data ?? []).length}</span>
        </div>
        {list.isLoading && <p className="eo-mute">…</p>}
        {!list.isLoading && (list.data ?? []).length === 0 && (
          <p className="eo-empty">{t("pages.humanLabels.empty")}</p>
        )}
        <ul style={{ margin: 0, paddingLeft: 0, listStyle: "none" }}>
          {(list.data ?? []).map((row) => (
            <li
              key={row.id}
              style={{
                padding: "8px 0",
                borderBottom: "1px solid var(--eo-border)",
                fontSize: 13,
              }}
            >
              <div
                style={{ display: "flex", justifyContent: "space-between", gap: 8 }}
              >
                <code className="mono" style={{ wordBreak: "break-all" }}>
                  {row.traceId}
                </code>
                <span className="eo-chip" data-tone="ok">
                  {row.humanVerdict}
                </span>
              </div>
              {row.expectedResponse && (
                <div className="eo-mute" style={{ marginTop: 4, fontSize: 12 }}>
                  {row.expectedResponse.slice(0, 200)}
                  {row.expectedResponse.length > 200 ? "…" : ""}
                </div>
              )}
              <div style={{ marginTop: 6, display: "flex", gap: 8 }}>
                <Link
                  href={`/workspace/tracing/detail/?id=${encodeURIComponent(row.traceId)}`}
                  className="eo-link"
                >
                  {t("pages.humanLabels.openTrace")}
                </Link>
                {writable && (
                  <button
                    type="button"
                    className="eo-btn eo-btn-ghost"
                    style={{ fontSize: 12 }}
                    onClick={() => {
                      if (confirm("Delete this label?")) del.mutate(row.id);
                    }}
                  >
                    {t("pages.humanLabels.delete")}
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
