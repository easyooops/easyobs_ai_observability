// IMPORTANT: must return the SAME value on server and client to avoid a
// React hydration mismatch. `NEXT_PUBLIC_API_URL` is inlined at build time,
// so this is stable across the SSR → hydrate boundary.
export const apiBase = () =>
  process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8787";

const TOKEN_KEY = "easyobs.jwt";

/** Browser-side JWT storage. SSR returns null so render output is stable. */
export const tokenStore = {
  get(): string | null {
    if (typeof window === "undefined") return null;
    return window.localStorage.getItem(TOKEN_KEY);
  },
  set(token: string): void {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(TOKEN_KEY, token);
  },
  clear(): void {
    if (typeof window === "undefined") return;
    window.localStorage.removeItem(TOKEN_KEY);
  },
};

/** Raised when the API returns 401, so callers can route the user back to
 * the sign-in page without parsing string messages. */
export class UnauthorizedError extends Error {
  constructor(public path: string) {
    super(`unauthorized: ${path}`);
    this.name = "UnauthorizedError";
  }
}

function authHeaders(): Record<string, string> {
  const t = tokenStore.get();
  return t ? { Authorization: `Bearer ${t}` } : {};
}

async function jget<T>(path: string): Promise<T> {
  const r = await fetch(`${apiBase()}${path}`, {
    cache: "no-store",
    headers: { ...authHeaders() },
  });
  if (r.status === 401) throw new UnauthorizedError(path);
  if (!r.ok) throw new Error(`${path} ${r.status}`);
  return (await r.json()) as T;
}

async function jreq<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { ...authHeaders() };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const r = await fetch(`${apiBase()}${path}`, {
    method,
    cache: "no-store",
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  if (r.status === 401) throw new UnauthorizedError(path);
  if (!r.ok) {
    let detail = "";
    try {
      detail = (await r.json())?.detail ?? "";
    } catch {}
    throw new Error(`${path} ${r.status}${detail ? ` – ${detail}` : ""}`);
  }
  if (r.status === 204) return undefined as T;
  return (await r.json()) as T;
}

// ---------------------------------------------------------------------------
// Auth & directory types
// ---------------------------------------------------------------------------

export type Role = "SA" | "PO" | "DV";
export type MembershipStatus = "pending" | "approved" | "rejected";

export type AuthUser = {
  id: string;
  email: string;
  displayName: string;
  isSuperAdmin: boolean;
};

export type AuthOrganization = {
  id: string;
  name: string;
  slug: string;
  isDefault: boolean;
};

export type AuthMembership = {
  orgId: string;
  orgName: string;
  role: Exclude<Role, "SA">;
  status: MembershipStatus;
  requestedAt: string;
  approvedAt: string | null;
};

export type SignInResponse = {
  token: string;
  user: AuthUser;
  approvedMemberships: AuthMembership[];
  currentOrg: AuthOrganization | null;
  isPlatformAdmin?: boolean;
  isPlatformMember?: boolean;
};

export type SignUpResponse = {
  token: string;
  user: AuthUser;
  isFirstUser: boolean;
  membership: AuthMembership | null;
  currentOrg: AuthOrganization | null;
  isPlatformAdmin?: boolean;
  isPlatformMember?: boolean;
};

export type SelectOrgResponse = {
  token: string;
  currentOrg: AuthOrganization;
  role: Role;
  accessibleServiceIds: string[];
  isPlatformAdmin?: boolean;
  isPlatformMember?: boolean;
};

// Platform admin = SA (bootstrapped) or any approved PO of the
// ``administrator`` org. Such accounts get effective-SA powers across
// every other org in the UI (Settings, Organizations, member edits, ...).
// Platform member = platform admin OR any approved DV of the administrator
// org — these accounts get cross-org *read* but cannot mutate.
export type MeResponse = {
  user: AuthUser;
  currentOrg: AuthOrganization | null;
  role: Role | null;
  approvedMemberships: AuthMembership[];
  pendingMemberships: AuthMembership[];
  accessibleServiceIds: string[] | null;
  isPlatformAdmin?: boolean;
  isPlatformMember?: boolean;
};

export type PublicOrganizationsResponse = {
  organizations: AuthOrganization[];
  hasUsers: boolean;
};

export const fetchPublicOrganizations = () =>
  jget<PublicOrganizationsResponse>("/v1/auth/public-organizations");

export const signIn = (email: string, password: string) =>
  jreq<SignInResponse>("POST", "/v1/auth/sign-in", { email, password });

export const signUp = (body: {
  email: string;
  password: string;
  displayName: string;
  orgId?: string;
  requestedRole?: "PO" | "DV";
}) => jreq<SignUpResponse>("POST", "/v1/auth/sign-up", body);

export const selectOrg = (orgId: string) =>
  jreq<SelectOrgResponse>("POST", "/v1/auth/select-org", { orgId });

export const fetchMe = () => jget<MeResponse>("/v1/auth/me");

export const requestAccess = (orgId: string, requestedRole: "PO" | "DV") =>
  jreq<AuthMembership>("POST", "/v1/auth/request-access", {
    orgId,
    requestedRole,
  });

// ---------------------------------------------------------------------------
// Organizations / members / services / tokens
// ---------------------------------------------------------------------------

export type OrganizationDetail = {
  id: string;
  name: string;
  slug: string;
  isDefault: boolean;
  createdAt: string;
};

export type MemberRow = {
  userId: string;
  orgId: string;
  role: "PO" | "DV";
  status: MembershipStatus;
  requestedAt: string;
  approvedAt: string | null;
  userEmail: string;
  userDisplayName: string;
  /** True when the row represents the bootstrapped super admin. The server
   * also rejects PATCH/DELETE on these memberships; the flag lets the UI
   * lock the row up-front instead of relying on an error toast. */
  userIsSuperAdmin: boolean;
};

export type ServiceRow = {
  id: string;
  orgId: string;
  name: string;
  slug: string;
  description: string;
  createdAt: string;
};

export const fetchOrganizations = () =>
  jget<OrganizationDetail[]>("/v1/organizations");

export const createOrganization = (name: string) =>
  jreq<OrganizationDetail>("POST", "/v1/organizations", { name });

export const fetchOrgMembers = (orgId: string) =>
  jget<MemberRow[]>(`/v1/organizations/${orgId}/members`);

export const updateMember = (
  orgId: string,
  userId: string,
  body: { status?: MembershipStatus; role?: "PO" | "DV" },
) => jreq<MemberRow>("PATCH", `/v1/organizations/${orgId}/members/${userId}`, body);

export const removeMember = (orgId: string, userId: string) =>
  jreq<void>("DELETE", `/v1/organizations/${orgId}/members/${userId}`);

export const fetchMemberServices = (orgId: string, userId: string) =>
  jget<string[]>(`/v1/organizations/${orgId}/members/${userId}/services`);

export const setMemberServices = (
  orgId: string,
  userId: string,
  serviceIds: string[],
) =>
  jreq<string[]>(
    "PUT",
    `/v1/organizations/${orgId}/members/${userId}/services`,
    { serviceIds },
  );

export const fetchOrgServices = (orgId: string) =>
  jget<ServiceRow[]>(`/v1/organizations/${orgId}/services`);

export const createService = (
  orgId: string,
  body: { name: string; description?: string },
) =>
  jreq<ServiceRow>("POST", `/v1/organizations/${orgId}/services`, {
    name: body.name,
    description: body.description ?? "",
  });

export const deleteService = (orgId: string, serviceId: string) =>
  jreq<void>("DELETE", `/v1/organizations/${orgId}/services/${serviceId}`);

// ---------------------------------------------------------------------------
// Service-scoped ingest tokens
// ---------------------------------------------------------------------------

export type IngestTokenRow = {
  id: number;
  serviceId: string;
  label: string;
  preview: string;
  createdAt: string;
  lastUsedAt: string | null;
  revoked: boolean;
};

export type IngestTokenCreated = {
  token: IngestTokenRow;
  secret: string;
};

export const fetchServiceTokens = (serviceId: string) =>
  jget<IngestTokenRow[]>(`/v1/services/${serviceId}/tokens`);

export const createServiceToken = (serviceId: string, label: string) =>
  jreq<IngestTokenCreated>("POST", `/v1/services/${serviceId}/tokens`, { label });

export const revokeServiceToken = (serviceId: string, tokenId: number) =>
  jreq<void>("DELETE", `/v1/services/${serviceId}/tokens/${tokenId}`);

// ---------------------------------------------------------------------------
// Trace / analytics types & calls
// ---------------------------------------------------------------------------

export type TraceListItem = {
  traceId: string;
  serviceId?: string;
  startedAt: string;
  endedAt: string | null;
  rootName: string;
  status: "OK" | "ERROR" | "UNSET" | string;
  serviceName: string;
  spanCount: number;
  // Optional LLM-enrichment fields, populated only when the request was
  // made with `withLlm: true`. Surfaced as flat columns in the trace
  // list so the table can render them without a per-row fetch.
  session?: string | null;
  user?: string | null;
  tokensIn?: number;
  tokensOut?: number;
  tokensTotal?: number;
  price?: number;
  model?: string | null;
  models?: string[];
};

export type SpanLlm = {
  kind: string | null;
  step: string | null;
  query: string | null;
  response: string | null;
  model: string | null;
  vendor: string | null;
  tokensIn: number;
  tokensOut: number;
  tokensTotal: number;
  price: number;
  docsCount: number;
  docsTopScore: number | null;
  docsRaw: string | null;
  tool: string | null;
  session: string | null;
  user: string | null;
  request: string | null;
  verdict: string | null;
  score: number | null;
  attempt: number | null;
};

export type SpanRow = {
  traceId: string;
  spanId: string;
  parentSpanId?: string | null;
  name: string;
  serviceName: string;
  status: string;
  attributes?: Array<{ key: string; value?: Record<string, unknown> }>;
  events?: Array<{ name: string; timeUnixNano?: number; attributes?: unknown }>;
  startTimeUnixNano?: number | null;
  endTimeUnixNano?: number | null;
  llm?: SpanLlm;
};

export type TraceLlmSummary = {
  session: string | null;
  user: string | null;
  request: string | null;
  query: string | null;
  response: string | null;
  tokensIn: number;
  tokensOut: number;
  tokensTotal: number;
  price: number;
  models: string[];
  vendors: string[];
  docsCount: number;
  llmCalls: number;
  retrieveCalls: number;
  toolCalls: number;
  verdicts: string[];
};

export type OverviewKpi = {
  totalTraces: number;
  errorTraces: number;
  okTraces: number;
  unsetTraces: number;
  errorRate: number;
  p50LatencyMs: number;
  p90LatencyMs: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  uniqueServices: number;
};

export type OverviewSeries = {
  bucketCount: number;
  bucketSpanSec: number;
  startedAt: string;
  total: number[];
  errors: number[];
  p95Ms: number[];
};

export type ServiceStat = {
  name: string;
  count: number;
  errorCount: number;
  errorRate: number;
  p50: number;
  p95: number;
};

export type TopOp = {
  name: string;
  count: number;
  p50: number;
  p95: number;
};

export type LlmStats = {
  tokensIn: number;
  tokensOut: number;
  tokensTotal: number;
  price: number;
  llmCalls: number;
  retrieveCalls: number;
  toolCalls: number;
  tracesWithLlm: number;
  uniqueSessions: number;
  topModels: Array<{ name: string; count: number }>;
  topVendors: Array<{ name: string; count: number }>;
  topSteps: Array<{ name: string; count: number }>;
};

export type Overview = {
  windowHours: number;
  generatedAt: string;
  kpi: OverviewKpi;
  series: OverviewSeries;
  statusMix: { OK: number; ERROR: number; UNSET: number };
  latencyBands: Array<{ label: string; count: number }>;
  services: ServiceStat[];
  topOperations: TopOp[];
  llm: LlmStats;
};

/** A conversational session: many traces tied together by an `o.sess`
 * attribute. The hierarchy is `session > traces > spans`, so this row
 * deliberately stays minimal — per-trace metrics (errors, latency, tokens,
 * cost, models) live in the trace list, not here.
 *
 * `traceIds` is ordered chronologically (oldest → newest) so the inspector
 * can render a clean "turn history" without an extra round-trip. */
export type SessionRow = {
  sessionId: string;
  serviceName: string;
  user: string | null;
  traceCount: number;
  errorCount: number;
  firstSeenAt: string;
  lastSeenAt: string;
  // Aggregate roll-ups, kept for the drawer summary (not the main grid).
  tokensIn: number;
  tokensOut: number;
  tokensTotal: number;
  price: number;
  models: string[];
  traceIds: string[];
};

export type SpanListRow = {
  traceId: string;
  spanId: string;
  parentSpanId: string | null;
  name: string;
  serviceName: string;
  status: string;
  durationMs: number;
  startTimeUnixNano?: number | null;
  endTimeUnixNano?: number | null;
  kind?: string | null;
  step?: string | null;
  model?: string | null;
  tokensTotal?: number;
  price?: number;
};

export type TraceDetail = {
  traceId: string;
  serviceId?: string;
  startedAt: string;
  endedAt: string | null;
  rootName: string;
  status: string;
  serviceName: string;
  spanCount: number;
  spans: SpanRow[];
  llmSummary: TraceLlmSummary;
};

/** Either a rolling window or an explicit timestamp range.
 * Mirrors `ResolvedRange` in lib/context.tsx so callers can pass the context
 * value straight through without an extra type import. */
export type RangeArg =
  | number
  | { kind: "window"; windowHours: number }
  | { kind: "range"; fromIso: string; toIso: string }
  | undefined;

/** Render a `RangeArg` into the `&window_hours=…` or `&from_ts=…&to_ts=…`
 * fragment accepted by every analytics endpoint. */
export function rangeParam(arg: RangeArg): string {
  if (arg == null) return "";
  if (typeof arg === "number") {
    return arg > 0 ? `&window_hours=${arg}` : "";
  }
  if (arg.kind === "window") {
    return arg.windowHours > 0 ? `&window_hours=${arg.windowHours}` : "";
  }
  return (
    `&from_ts=${encodeURIComponent(arg.fromIso)}` +
    `&to_ts=${encodeURIComponent(arg.toIso)}`
  );
}

/** Options for filtering / enriching the trace list.
 *
 * - `sessionId` restricts the result to one conversational session — same
 *   filter that the Sessions page uses to drill into a session's traces.
 * - `withLlm` tells the server to attach LLM roll-ups (tokens / price /
 *   model / session) per row so the UI can render those columns without
 *   fetching the trace detail for every row. */
export type TraceListOpts = {
  sessionId?: string;
  withLlm?: boolean;
  limit?: number;
};

export const fetchTraces = (range?: RangeArg, opts: TraceListOpts = {}) => {
  const limit = opts.limit ?? 500;
  const parts = [`limit=${limit}`];
  if (opts.sessionId) parts.push(`session_id=${encodeURIComponent(opts.sessionId)}`);
  if (opts.withLlm) parts.push("with_llm=true");
  const qs = parts.join("&");
  return jget<{ items: TraceListItem[] }>(`/v1/traces?${qs}${rangeParam(range)}`).then(
    (j) => j.items,
  );
};

export const fetchTraceDetail = (traceId: string) =>
  jget<TraceDetail>(`/v1/traces/${encodeURIComponent(traceId)}`);

export const fetchOverview = (range?: RangeArg, buckets = 24) => {
  // Overview needs bucket math: if no range given, fall back to 24h window.
  // `rangeParam` returns a leading "&" we drop so the query string is well
  // formed even when no time filter is selected.
  const p = (range ? rangeParam(range) : rangeParam(24)).replace(/^&/, "");
  const qs = [p, `buckets=${buckets}`].filter(Boolean).join("&");
  return jget<Overview>(`/v1/analytics/overview?${qs}`);
};

export const fetchSessions = (range?: RangeArg) =>
  jget<{ items: SessionRow[] }>(
    `/v1/analytics/sessions?limit=200${rangeParam(range)}`,
  ).then((j) => j.items);

export const fetchSpans = (range?: RangeArg) =>
  jget<{ items: SpanListRow[] }>(
    `/v1/analytics/spans?limit=200${rangeParam(range)}`,
  ).then((j) => j.items);

// ---------------------------------------------------------------------------
// Settings > Storage
// ---------------------------------------------------------------------------

export type BlobProvider = "local" | "s3" | "azure" | "gcs";
export type CatalogProvider = "sqlite" | "postgres";

export type BlobSettings = {
  provider: BlobProvider;
  path: string;
  bucket: string;
  prefix: string;
  region: string;
  s3_access_key_id: string;
  /** Backend masks secrets on GET — empty string = "not set", "••• set •••"
   * = "we have one but won't echo it". Send the literal mask back unchanged
   * to keep the existing secret; send a real string to overwrite. */
  s3_secret_access_key: string;
  azure_account_name: string;
  azure_account_key: string;
  azure_container: string;
  gcs_service_account_json: string;
};

export type CatalogSettings = {
  provider: CatalogProvider;
  sqlite_path: string;
  pg_host: string;
  pg_port: number;
  pg_database: string;
  pg_user: string;
  pg_password: string;
  pg_sslmode: "disable" | "allow" | "prefer" | "require" | "verify-full";
};

export type RetentionSettings = {
  enabled: boolean;
  days: number;
};

export type StorageSettings = {
  blob: BlobSettings;
  catalog: CatalogSettings;
  retention: RetentionSettings;
  active: {
    blob: { provider: string; path: string };
    catalog: { provider: string; url: string };
  };
  restartRequired: boolean;
};

export const fetchStorageSettings = () =>
  jget<StorageSettings>("/v1/settings/storage");

export const saveStorageSettings = (body: {
  blob: BlobSettings;
  catalog: CatalogSettings;
  retention: RetentionSettings;
}) => jreq<StorageSettings>("PUT", "/v1/settings/storage", body);

export type StorageTestResult = { ok: boolean; message: string };

export const testBlobConnection = (cfg: BlobSettings) =>
  jreq<StorageTestResult>("POST", "/v1/settings/storage/blob/test", cfg);

export const testCatalogConnection = (cfg: CatalogSettings) =>
  jreq<StorageTestResult>("POST", "/v1/settings/storage/catalog/test", cfg);

// ---------------------------------------------------------------------------
// Quality (Evaluation) module
//
// All endpoints below are gated server-side on the (org × service) access
// matrix the trace surface already enforces, so we don't filter again on
// the client. We do, however, send `project_id` (= service id) on writes so
// the server can persist multi-tenant ownership.
// ---------------------------------------------------------------------------

export type EvaluatorKind = "rule" | "judge";
export type EvaluatorLayer = "L1" | "L2" | "L3";

export type EvaluatorCatalogEntry = {
  id: string;
  name: string;
  category: string;
  description: string;
  layer: EvaluatorLayer;
  defaultParams: Record<string, unknown>;
  /** Metric code when this row comes from ``eval_metric_catalog_v1.json`` */
  metricCode?: string;
  evaluationMode?: string;
  gt?: string;
  causeCode?: string;
  metricKind?: string;
  ruleTarget?: string;
  judgeDimension?: string;
};

export type JudgeModel = {
  id: string;
  orgId: string;
  name: string;
  provider: string;
  model: string;
  temperature: number;
  weight: number;
  costPer1kInput: number;
  costPer1kOutput: number;
  connectionConfig?: Record<string, unknown>;
  enabled: boolean;
  createdAt: string;
};

export type ConsensusPolicy = "single" | "majority" | "unanimous" | "weighted";
export type CostExceedAction = "block" | "downgrade" | "notify";

export type EvalProfileEvaluatorRef = {
  evaluatorId: string;
  weight: number;
  threshold: number;
  params: Record<string, unknown>;
};

export type EvalProfileJudgeRef = {
  modelId: string;
  weight: number;
};

export type EvalCostGuard = {
  maxCostUsdPerRun: number;
  maxCostUsdPerSubject: number;
  monthlyBudgetUsd: number;
  onExceed: CostExceedAction;
};

export type JudgeRubricMode = "append" | "replace";

export type EvalProfile = {
  id: string;
  orgId: string;
  projectId: string | null;
  name: string;
  description: string;
  evaluators: EvalProfileEvaluatorRef[];
  judgeModels: EvalProfileJudgeRef[];
  consensus: ConsensusPolicy;
  autoRun: boolean;
  costGuard: EvalCostGuard;
  enabled: boolean;
  createdAt: string;
  judgeRubricText?: string;
  judgeRubricMode?: JudgeRubricMode;
  judgeSystemPrompt?: string;
  judgeUserMessageTemplate?: string;
  improvementPack?: string;
  judgeDimensionPrompts?: Record<string, { en?: string; ko?: string }>;
  improvementContentLocale?: "en" | "ko" | string;
};

export type JudgeDimensionCorpus = {
  focus?: string;
  scoringHints?: string[];
};

export type JudgeDimensionCatalogEntry = {
  id: string;
  title: { en: string; ko: string };
  criterion: { en: string; ko: string };
  /** Shipped `metric_corpus_v1.json` slice for this dimension (read-only). */
  corpus?: JudgeDimensionCorpus;
};

export type SuggestedRuleEvaluator = {
  evaluatorId: string;
  weight: number;
  threshold: number;
  params: Record<string, unknown>;
};

export type ImprovementPackMeta = {
  id: string;
  label: string;
  labelI18n?: { en: string; ko: string };
  suggestedRuleEvaluators?: SuggestedRuleEvaluator[];
  /** Minimal-cost LLM-as-a-Judge metric ids to add when judges are enabled. */
  suggestedJudgeMetrics?: string[];
};

export type HumanLabelAnnotation = {
  id: string;
  traceId: string;
  projectId: string | null;
  expectedResponse: string;
  humanVerdict: string;
  notes: string;
  updatedAt: string;
};

export type ProfileSavePayload = {
  projectId: string | null;
  name: string;
  description?: string;
  evaluators: EvalProfileEvaluatorRef[];
  judgeModels: EvalProfileJudgeRef[];
  consensus: ConsensusPolicy;
  autoRun: boolean;
  costGuard: EvalCostGuard;
  enabled?: boolean;
  judgeRubricText?: string;
  judgeRubricMode?: JudgeRubricMode;
  judgeSystemPrompt?: string;
  judgeUserMessageTemplate?: string;
  improvementPack?: string;
  judgeDimensionPrompts?: Record<string, { en?: string; ko?: string }>;
  improvementContentLocale?: "en" | "ko" | string;
};

export type RunStatus = "running" | "succeeded" | "failed" | "cancelled" | string;
export type TriggerLane =
  | "rule_auto"
  | "judge_manual"
  | "judge_schedule"
  | string;

export type EvalRunMode =
  | "trace"
  | "human_label"
  | "golden_gt"
  | "golden_judge";

export type HumanLabelIn = {
  traceId: string;
  expectedResponse?: string | null;
  humanVerdict?: string | null;
  notes?: string;
};

export type EvalRun = {
  id: string;
  orgId: string;
  projectId: string | null;
  profileId: string | null;
  scheduleId: string | null;
  triggerLane: TriggerLane;
  triggeredBy: string | null;
  status: RunStatus;
  subjectCount: number;
  completedCount: number;
  failedCount: number;
  costEstimateUsd: number;
  costActualUsd: number;
  passRate: number;
  avgScore: number;
  notes: string;
  startedAt: string;
  finishedAt: string | null;
  runMode?: EvalRunMode;
  goldenSetId?: string | null;
  runContext?: Record<string, unknown>;
};

export type Verdict = "pass" | "fail" | "warn" | string;

export type EvalFinding = {
  evaluatorId: string;
  kind: EvaluatorKind | string;
  score: number;
  verdict: Verdict;
  reason: string;
  details: Record<string, unknown>;
};

export type JudgePerModel = {
  modelId: string;
  score: number;
  verdict: Verdict;
  reason: string;
  inputTokens: number;
  outputTokens: number;
  costUsd: number;
};

export type EvalResult = {
  id: string;
  runId: string;
  orgId: string;
  projectId: string | null;
  traceId: string;
  sessionId?: string | null;
  score: number;
  verdict: Verdict;
  ruleScore: number;
  judgeScore: number | null;
  judgeDisagreement: number | null;
  judgeInputTokens: number;
  judgeOutputTokens: number;
  judgeCostUsd: number;
  findings: EvalFinding[];
  judgePerModel: JudgePerModel[] | Record<string, unknown>[];
  triggerLane: TriggerLane;
  createdAt: string;
};

export type GoldenLayer = "L1" | "L2" | "L3";

export type GoldenSet = {
  id: string;
  orgId: string;
  projectId: string | null;
  name: string;
  layer: GoldenLayer;
  description: string;
  itemCount: number;
  createdAt: string;
};

export type GoldenItem = {
  id: string;
  setId: string;
  orgId: string;
  projectId: string | null;
  layer: GoldenLayer;
  sourceKind: "human_manual" | "auto_synth" | "trace_label" | string;
  status: "draft" | "approved" | "deprecated" | string;
  payload: Record<string, unknown>;
  sourceTraceId: string | null;
  createdAt: string;
};

export type EvalSchedule = {
  id: string;
  orgId: string;
  projectId: string;
  profileId: string;
  name: string;
  intervalHours: number;
  cron: string;
  sampleSize: number;
  enabled: boolean;
  lastRunAt: string | null;
  nextRunAt: string | null;
  createdAt: string;
};

export type EffortLevel = "low" | "medium" | "high";

export type SecondaryCandidate = {
  category: string;
  group: string;
  effort: EffortLevel | string;
  labelI18n?: { en?: string; ko?: string };
};

export type ImprovementProposal = {
  category: string;
  title: string;
  rationale: string;
  expectedLift: number;
  effort: EffortLevel | string;
  categoryLabel?: string;
  titleI18n?: { en?: string; ko?: string };
  categoryLabelI18n?: { en?: string; ko?: string };
  actionsI18n?: { en?: string[]; ko?: string[] };
  /** Detailed taxonomy key — e.g. ``retrieval.tune`` (one of 46). */
  categoryDetail?: string | null;
  /** Detailed group key — e.g. ``retrieval`` (one of 11). */
  categoryGroup?: string | null;
  categoryDetailLabelI18n?: { en?: string; ko?: string };
  categoryDetailSummaryI18n?: { en?: string; ko?: string };
  /** Optional Judge-driven rationale for upgrading the default effort. */
  effortReason?: string | null;
  /** Cause code from the metric catalog (when available). */
  causeCode?: string | null;
  /** Detailed alternatives the operator can also try. */
  secondaryCandidates?: SecondaryCandidate[];
};

export type Improvement = {
  id: string;
  orgId: string;
  projectId: string | null;
  resultId: string;
  traceId: string;
  summary: string;
  proposals: ImprovementProposal[];
  judgeModels: string[];
  consensusPolicy: ConsensusPolicy;
  agreementRatio: number;
  judgeCostUsd: number;
  status: "open" | "accepted" | "rejected" | string;
  createdAt: string;
  improvementPack?: string | null;
  improvementContentLocale?: string | null;
};

export type RunEstimate = {
  subjectCount: number;
  judgeCalls: number;
  costEstimateUsd: number;
  ruleOnly: boolean;
  monthlySpentUsd: number;
  costGuard: { allowed: boolean; downgrade: boolean; note: string };
};

export type CostDailyRow = {
  day: string;
  projectId: string | null;
  profileId: string | null;
  judgeCalls: number;
  judgeInputTokens: number;
  judgeOutputTokens: number;
  judgeCostUsd: number;
  ruleEvals: number;
};

export type CostOverview = {
  monthCostUsd: number;
  judgeCalls: number;
  ruleEvals: number;
  judgeInputTokens: number;
  judgeOutputTokens: number;
  daily: CostDailyRow[];
};

export type QualityOverview = {
  kpi: {
    profileCount: number;
    judgeModelCount: number;
    goldenSetCount: number;
    openImprovements: number;
    avgScore: number;
    passRate: number;
    autoRuleRunsLast20: number;
  };
  recentRuns: EvalRun[];
  cost: CostOverview;
};

// Evaluator catalog & judge models -----------------------------------------

export const fetchEvaluatorCatalog = () =>
  jget<{ items: EvaluatorCatalogEntry[] }>("/v1/evaluations/evaluators").then(
    (j) => j.items,
  );

export const fetchJudgeModels = (includeDisabled = false) =>
  jget<{ items: JudgeModel[] }>(
    `/v1/evaluations/judge-models?include_disabled=${includeDisabled}`,
  ).then((j) =>
    j.items.map((m) => ({
      ...m,
      connectionConfig: m.connectionConfig ?? {},
    })),
  );

export const createJudgeModel = (body: {
  name: string;
  provider: string;
  model: string;
  temperature: number;
  weight: number;
  costPer1kInput: number;
  costPer1kOutput: number;
  connectionConfig?: Record<string, unknown>;
  enabled: boolean;
}) =>
  jreq<JudgeModel>("POST", "/v1/evaluations/judge-models", {
    name: body.name,
    provider: body.provider,
    model: body.model,
    temperature: body.temperature,
    weight: body.weight,
    cost_per_1k_input: body.costPer1kInput,
    cost_per_1k_output: body.costPer1kOutput,
    connection_config: body.connectionConfig ?? {},
    enabled: body.enabled,
  });

export const patchJudgeModel = (
  modelId: string,
  body: Partial<{
    name: string;
    provider: string;
    model: string;
    temperature: number;
    weight: number;
    costPer1kInput: number;
    costPer1kOutput: number;
    connectionConfig: Record<string, unknown>;
    enabled: boolean;
  }>,
) =>
  jreq<JudgeModel>(
    "PATCH",
    `/v1/evaluations/judge-models/${encodeURIComponent(modelId)}`,
    {
      ...(body.name !== undefined && { name: body.name }),
      ...(body.provider !== undefined && { provider: body.provider }),
      ...(body.model !== undefined && { model: body.model }),
      ...(body.temperature !== undefined && { temperature: body.temperature }),
      ...(body.weight !== undefined && { weight: body.weight }),
      ...(body.costPer1kInput !== undefined && {
        cost_per_1k_input: body.costPer1kInput,
      }),
      ...(body.costPer1kOutput !== undefined && {
        cost_per_1k_output: body.costPer1kOutput,
      }),
      ...(body.connectionConfig !== undefined && {
        connection_config: body.connectionConfig,
      }),
      ...(body.enabled !== undefined && { enabled: body.enabled }),
    },
  );

export const deleteJudgeModel = (modelId: string) =>
  jreq<void>(
    "DELETE",
    `/v1/evaluations/judge-models/${encodeURIComponent(modelId)}`,
  );

// Profiles -----------------------------------------------------------------

function profilePayload(body: ProfileSavePayload) {
  return {
    project_id: body.projectId,
    name: body.name,
    description: body.description ?? "",
    evaluators: body.evaluators.map((e) => ({
      evaluator_id: e.evaluatorId,
      weight: e.weight,
      threshold: e.threshold,
      params: e.params,
    })),
    judge_models: body.judgeModels.map((j) => ({
      model_id: j.modelId,
      weight: j.weight,
    })),
    consensus: body.consensus,
    auto_run: body.autoRun,
    cost_guard: {
      max_cost_usd_per_run: body.costGuard.maxCostUsdPerRun,
      max_cost_usd_per_subject: body.costGuard.maxCostUsdPerSubject,
      monthly_budget_usd: body.costGuard.monthlyBudgetUsd,
      on_exceed: body.costGuard.onExceed,
    },
    enabled: body.enabled ?? true,
    judge_rubric_text: body.judgeRubricText ?? "",
    judge_rubric_mode: body.judgeRubricMode ?? "append",
    judge_system_prompt: body.judgeSystemPrompt ?? "",
    judge_user_message_template: body.judgeUserMessageTemplate ?? "",
    improvement_pack: body.improvementPack ?? "easyobs_standard",
    judge_dimension_prompts: body.judgeDimensionPrompts ?? {},
    improvement_content_locale: "en",
  };
}

export const fetchJudgeDimensions = () =>
  jget<{ items: JudgeDimensionCatalogEntry[] }>("/v1/evaluations/judge-dimensions").then(
    (j) => j.items,
  );

function normalizeSuggestedRow(row: unknown): SuggestedRuleEvaluator | null {
  if (!row || typeof row !== "object") return null;
  const o = row as Record<string, unknown>;
  const eid = o.evaluatorId ?? o.evaluator_id;
  if (typeof eid !== "string" || !eid.trim()) return null;
  const w = Number(o.weight);
  const th = Number(o.threshold);
  const params = o.params;
  return {
    evaluatorId: eid.trim(),
    weight: Number.isFinite(w) ? w : 1,
    threshold: Number.isFinite(th) ? th : 0.6,
    params: params && typeof params === "object" && !Array.isArray(params) ? { ...(params as object) } : {},
  };
}

function normalizeImprovementPack(row: unknown): ImprovementPackMeta | null {
  if (!row || typeof row !== "object") return null;
  const o = row as Record<string, unknown>;
  const id = typeof o.id === "string" ? o.id : "";
  if (!id) return null;
  const label = typeof o.label === "string" ? o.label : id;
  const labelI18n = o.labelI18n ?? o.label_i18n;
  const sugRaw = o.suggestedRuleEvaluators ?? o.suggested_rule_evaluators;
  const judgeRaw = o.suggestedJudgeMetrics ?? o.suggested_judge_metrics;
  const suggestedRuleEvaluators = Array.isArray(sugRaw)
    ? (sugRaw.map(normalizeSuggestedRow).filter(Boolean) as SuggestedRuleEvaluator[])
    : undefined;
  return {
    id,
    label,
    labelI18n:
      labelI18n && typeof labelI18n === "object"
        ? (labelI18n as { en: string; ko: string })
        : undefined,
    suggestedRuleEvaluators,
    suggestedJudgeMetrics: Array.isArray(judgeRaw)
      ? judgeRaw.map((x) => String(x)).filter((x) => x.length > 0)
      : undefined,
  };
}

export const fetchImprovementPacks = () =>
  jget<{ items: unknown[] }>("/v1/evaluations/improvement-packs").then((j) =>
    (j.items ?? []).map(normalizeImprovementPack).filter(Boolean) as ImprovementPackMeta[],
  );

export const fetchHumanLabelAnnotations = (limit = 80) =>
  jget<{ items: HumanLabelAnnotation[] }>(
    `/v1/evaluations/human-labels?limit=${encodeURIComponent(String(limit))}`,
  ).then((j) => j.items);

export const upsertHumanLabelAnnotation = (body: {
  traceId: string;
  projectId?: string | null;
  expectedResponse?: string;
  humanVerdict?: string;
  notes?: string;
}) =>
  jreq<Record<string, unknown>>("POST", "/v1/evaluations/human-labels", {
    trace_id: body.traceId,
    project_id: body.projectId ?? null,
    expected_response: body.expectedResponse ?? "",
    human_verdict: body.humanVerdict ?? "",
    notes: body.notes ?? "",
  });

export const deleteHumanLabelAnnotation = (annotationId: string) =>
  jreq<void>("DELETE", `/v1/evaluations/human-labels/${encodeURIComponent(annotationId)}`);

export const fetchEvalProfiles = (includeDisabled = false) =>
  jget<{ items: EvalProfile[] }>(
    `/v1/evaluations/profiles?include_disabled=${includeDisabled}`,
  ).then((j) => j.items);

export const fetchEvalProfile = (profileId: string) =>
  jget<EvalProfile>(`/v1/evaluations/profiles/${encodeURIComponent(profileId)}`);

export const createEvalProfile = (body: ProfileSavePayload) =>
  jreq<EvalProfile>("POST", "/v1/evaluations/profiles", profilePayload(body));

export const replaceEvalProfile = (profileId: string, body: ProfileSavePayload) =>
  jreq<EvalProfile>(
    "PUT",
    `/v1/evaluations/profiles/${encodeURIComponent(profileId)}`,
    profilePayload(body),
  );

export const deleteEvalProfile = (profileId: string) =>
  jreq<void>(
    "DELETE",
    `/v1/evaluations/profiles/${encodeURIComponent(profileId)}`,
  );

// Runs ---------------------------------------------------------------------

export const estimateEvalRun = (body: {
  profileId: string;
  subjectCount: number;
  projectId?: string | null;
}) =>
  jreq<RunEstimate>("POST", "/v1/evaluations/runs:estimate", {
    profile_id: body.profileId,
    subject_count: body.subjectCount,
    project_id: body.projectId ?? null,
  });

export const createEvalRun = (body: {
  profileId: string;
  projectId: string | null;
  traceIds: string[];
  triggerLane?: TriggerLane;
  notes?: string;
  runMode?: EvalRunMode;
  goldenSetId?: string | null;
  runContext?: Record<string, unknown>;
  humanLabels?: HumanLabelIn[];
}) =>
  jreq<EvalRun>("POST", "/v1/evaluations/runs", {
    profile_id: body.profileId,
    project_id: body.projectId,
    trace_ids: body.traceIds,
    trigger_lane: body.triggerLane ?? "judge_manual",
    notes: body.notes ?? "",
    run_mode: body.runMode ?? "trace",
    golden_set_id: body.goldenSetId ?? null,
    run_context: body.runContext ?? {},
    human_labels: (body.humanLabels ?? []).map((h) => ({
      trace_id: h.traceId,
      expected_response: h.expectedResponse ?? null,
      human_verdict: h.humanVerdict ?? null,
      notes: h.notes ?? "",
    })),
  });

export const fetchEvalRuns = (limit = 100) =>
  jget<{ items: EvalRun[] }>(`/v1/evaluations/runs?limit=${limit}`).then(
    (j) => j.items,
  );

export const fetchEvalRun = (runId: string) =>
  jget<EvalRun>(`/v1/evaluations/runs/${encodeURIComponent(runId)}`);

export const fetchEvalResults = (runId: string, limit = 500) =>
  jget<{ items: EvalResult[] }>(
    `/v1/evaluations/runs/${encodeURIComponent(runId)}/results?limit=${limit}`,
  ).then((j) => j.items);

export const fetchEvalResult = (resultId: string) =>
  jget<EvalResult>(`/v1/evaluations/results/${encodeURIComponent(resultId)}`);

// Golden sets --------------------------------------------------------------

export const fetchGoldenSets = () =>
  jget<{ items: GoldenSet[] }>("/v1/evaluations/golden-sets").then(
    (j) => j.items,
  );

export const createGoldenSet = (body: {
  projectId: string | null;
  name: string;
  layer: GoldenLayer;
  description?: string;
}) =>
  jreq<GoldenSet>("POST", "/v1/evaluations/golden-sets", {
    project_id: body.projectId,
    name: body.name,
    layer: body.layer,
    description: body.description ?? "",
  });

export const deleteGoldenSet = (setId: string) =>
  jreq<void>(
    "DELETE",
    `/v1/evaluations/golden-sets/${encodeURIComponent(setId)}`,
  );

export const fetchGoldenItems = (
  setId: string,
  opts: { status?: string; limit?: number } = {},
) => {
  const parts: string[] = [];
  if (opts.status) parts.push(`status=${encodeURIComponent(opts.status)}`);
  if (opts.limit) parts.push(`limit=${opts.limit}`);
  const qs = parts.length ? `?${parts.join("&")}` : "";
  return jget<{ items: GoldenItem[] }>(
    `/v1/evaluations/golden-sets/${encodeURIComponent(setId)}/items${qs}`,
  ).then((j) => j.items);
};

export const addGoldenItem = (setId: string, payload: Record<string, unknown>) =>
  jreq<GoldenItem>(
    "POST",
    `/v1/evaluations/golden-sets/${encodeURIComponent(setId)}/items`,
    { payload },
  );

export const addGoldenItemFromTrace = (
  setId: string,
  body: { traceId: string; labels?: Record<string, unknown> },
) =>
  jreq<GoldenItem>(
    "POST",
    `/v1/evaluations/golden-sets/${encodeURIComponent(setId)}/items/from-trace`,
    { trace_id: body.traceId, labels: body.labels ?? {} },
  );

export const autoDiscoverGoldenItems = (
  setId: string,
  body: { projectId: string; sampleSize?: number },
) =>
  jreq<{ items: GoldenItem[] }>(
    "POST",
    `/v1/evaluations/golden-sets/${encodeURIComponent(setId)}/auto-discover`,
    { project_id: body.projectId, sample_size: body.sampleSize ?? 20 },
  ).then((j) => j.items);

export const updateGoldenItemStatus = (itemId: string, status: string) =>
  jreq<GoldenItem>(
    "PATCH",
    `/v1/evaluations/golden-items/${encodeURIComponent(itemId)}`,
    { status },
  );

export const deleteGoldenItem = (itemId: string) =>
  jreq<void>(
    "DELETE",
    `/v1/evaluations/golden-items/${encodeURIComponent(itemId)}`,
  );

// Schedules ----------------------------------------------------------------

export const fetchEvalSchedules = () =>
  jget<{ items: EvalSchedule[] }>("/v1/evaluations/schedules").then(
    (j) => j.items,
  );

export const createEvalSchedule = (body: {
  projectId: string;
  profileId: string;
  name: string;
  intervalHours: number;
  sampleSize: number;
  enabled: boolean;
}) =>
  jreq<EvalSchedule>("POST", "/v1/evaluations/schedules", {
    project_id: body.projectId,
    profile_id: body.profileId,
    name: body.name,
    interval_hours: body.intervalHours,
    sample_size: body.sampleSize,
    enabled: body.enabled,
  });

export const patchEvalSchedule = (
  scheduleId: string,
  body: Partial<{
    name: string;
    intervalHours: number;
    sampleSize: number;
    enabled: boolean;
  }>,
) =>
  jreq<EvalSchedule>(
    "PATCH",
    `/v1/evaluations/schedules/${encodeURIComponent(scheduleId)}`,
    {
      ...(body.name !== undefined && { name: body.name }),
      ...(body.intervalHours !== undefined && {
        interval_hours: body.intervalHours,
      }),
      ...(body.sampleSize !== undefined && { sample_size: body.sampleSize }),
      ...(body.enabled !== undefined && { enabled: body.enabled }),
    },
  );

export const deleteEvalSchedule = (scheduleId: string) =>
  jreq<void>(
    "DELETE",
    `/v1/evaluations/schedules/${encodeURIComponent(scheduleId)}`,
  );

// Improvements -------------------------------------------------------------

export const fetchImprovements = (
  opts: { status?: string; limit?: number } = {},
) => {
  const parts: string[] = [];
  if (opts.status) parts.push(`status=${encodeURIComponent(opts.status)}`);
  if (opts.limit) parts.push(`limit=${opts.limit}`);
  const qs = parts.length ? `?${parts.join("&")}` : "";
  return jget<{ items: Improvement[] }>(`/v1/evaluations/improvements${qs}`).then(
    (j) => j.items,
  );
};

export const updateImprovementStatus = (improvementId: string, status: string) =>
  jreq<Improvement>(
    "PATCH",
    `/v1/evaluations/improvements/${encodeURIComponent(improvementId)}`,
    { status },
  );

// Cost dashboard -----------------------------------------------------------

export const fetchEvalCostOverview = () =>
  jget<CostOverview>("/v1/evaluations/cost/overview");

export const fetchEvalCostDaily = (days = 30) =>
  jget<{ items: CostDailyRow[] }>(`/v1/evaluations/cost/daily?days=${days}`).then(
    (j) => j.items,
  );

// Aggregated ---------------------------------------------------------------

export const fetchQualityOverview = () =>
  jget<QualityOverview>("/v1/evaluations/overview");

// ---------------------------------------------------------------------------
// Alarms (threshold alerting)
//
// Server-side these endpoints live under /v1/organizations/{orgId}/alarms
// and the request is gated by the same RBAC matrix as the rest of the
// platform — DV may read their assigned services' rules, PO/SA may mutate.
// ---------------------------------------------------------------------------

export type AlarmChannelKind =
  | "slack"
  | "teams"
  | "discord"
  | "pagerduty"
  | "opsgenie"
  | "webhook"
  | "email";

export type AlarmSignalKind =
  | "trace_volume"
  | "error_rate"
  | "latency_p95"
  | "latency_p99"
  | "llm_cost_usd"
  | "llm_tokens_total"
  | "quality_pass_rate"
  | "quality_avg_score"
  | "judge_disagreement"
  | "improvement_open_count"
  | "judge_cost_usd_daily";

export type AlarmSurface = "observe_overview" | "quality_overview";
export type AlarmComparator = "gt" | "gte" | "lt" | "lte" | "eq";
export type AlarmSeverity = "info" | "warning" | "critical";
export type AlarmEventState = "firing" | "resolved";

export type ChannelFieldSpec = {
  key: string;
  label: string;
  type: "string" | "url" | "secret" | "number" | "select" | "multiline";
  required: boolean;
  placeholder: string;
  help: string;
  options: string[];
  secret: boolean;
};

export type AlarmChannelCatalogEntry = {
  kind: AlarmChannelKind;
  label: string;
  blurb: string;
  icon: string;
  accent: string;
  fields: ChannelFieldSpec[];
};

export type AlarmSignalCatalogEntry = {
  kind: AlarmSignalKind;
  label: string;
  blurb: string;
  surface: "observe" | "quality";
  unit: string;
  suggestedWindowMinutes: number;
  suggestedMinSamples: number;
  suggestedSeverity: AlarmSeverity;
  suggestedComparator: AlarmComparator;
  suggestedThreshold: number;
};

export type AlarmCatalog = {
  channels: AlarmChannelCatalogEntry[];
  signals: AlarmSignalCatalogEntry[];
};

export type AlarmChannel = {
  id: string;
  orgId: string;
  name: string;
  channelKind: AlarmChannelKind;
  config: Record<string, unknown>;
  enabled: boolean;
  lastTestAt: string | null;
  lastTestStatus: string;
  lastTestError: string;
  createdAt: string;
};

export type AlarmRule = {
  id: string;
  orgId: string;
  serviceId: string | null;
  name: string;
  description: string;
  signalKind: AlarmSignalKind;
  signalParams: Record<string, unknown>;
  comparator: AlarmComparator;
  threshold: number;
  windowMinutes: number;
  minSamples: number;
  dedupMinutes: number;
  severity: AlarmSeverity;
  enabled: boolean;
  channelIds: string[];
  lastEvaluatedAt: string | null;
  lastObservedValue: number | null;
  lastState: string;
  createdAt: string | null;
};

export type AlarmEvent = {
  id: string;
  ruleId: string;
  ruleName: string;
  orgId: string;
  serviceId: string | null;
  state: AlarmEventState;
  severity: AlarmSeverity;
  observedValue: number;
  threshold: number;
  startedAt: string;
  endedAt: string | null;
  context: Record<string, unknown>;
  deliveryAttempts: number;
  deliveryFailures: number;
  lastDeliveryError: string;
};

export type AlarmPin = {
  id: string;
  orgId: string;
  ruleId: string;
  surface: AlarmSurface;
  orderIndex: number;
};

export type AlarmOverview = {
  surface: AlarmSurface;
  items: Array<{ rule: AlarmRule; pin: AlarmPin }>;
};

export type AlarmTestOutcome = { ok: boolean; detail: string };

export const fetchAlarmCatalog = (orgId: string) =>
  jget<AlarmCatalog>(
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/catalog`,
  );

export const fetchAlarmChannels = (orgId: string) =>
  jget<AlarmChannel[]>(
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/channels`,
  );

export const createAlarmChannel = (
  orgId: string,
  body: {
    name: string;
    channelKind: AlarmChannelKind;
    config: Record<string, unknown>;
    enabled?: boolean;
  },
) =>
  jreq<AlarmChannel>(
    "POST",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/channels`,
    {
      name: body.name,
      channelKind: body.channelKind,
      config: body.config,
      enabled: body.enabled ?? true,
    },
  );

export const patchAlarmChannel = (
  orgId: string,
  channelId: string,
  body: Partial<{
    name: string;
    config: Record<string, unknown>;
    enabled: boolean;
  }>,
) =>
  jreq<AlarmChannel>(
    "PATCH",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/channels/${encodeURIComponent(
      channelId,
    )}`,
    body,
  );

export const deleteAlarmChannel = (orgId: string, channelId: string) =>
  jreq<void>(
    "DELETE",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/channels/${encodeURIComponent(
      channelId,
    )}`,
  );

export const testAlarmChannel = (orgId: string, channelId: string) =>
  jreq<AlarmTestOutcome>(
    "POST",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/channels/${encodeURIComponent(
      channelId,
    )}/test`,
  );

export const fetchAlarmRules = (orgId: string) =>
  jget<AlarmRule[]>(
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/rules`,
  );

export type AlarmRuleSavePayload = {
  name: string;
  serviceId?: string | null;
  description?: string;
  signalKind: AlarmSignalKind;
  signalParams?: Record<string, unknown>;
  comparator: AlarmComparator;
  threshold: number;
  windowMinutes?: number;
  minSamples?: number;
  dedupMinutes?: number;
  severity?: AlarmSeverity;
  enabled?: boolean;
  channelIds?: string[];
};

export const createAlarmRule = (orgId: string, body: AlarmRuleSavePayload) =>
  jreq<AlarmRule>(
    "POST",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/rules`,
    body,
  );

export const patchAlarmRule = (
  orgId: string,
  ruleId: string,
  body: Partial<AlarmRuleSavePayload>,
) =>
  jreq<AlarmRule>(
    "PATCH",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/rules/${encodeURIComponent(
      ruleId,
    )}`,
    body,
  );

export const deleteAlarmRule = (orgId: string, ruleId: string) =>
  jreq<void>(
    "DELETE",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/rules/${encodeURIComponent(
      ruleId,
    )}`,
  );

export const evaluateAlarmRule = (orgId: string, ruleId: string) =>
  jreq<AlarmRule>(
    "POST",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/rules/${encodeURIComponent(
      ruleId,
    )}/evaluate`,
  );

export const fetchAlarmEvents = (
  orgId: string,
  opts: { ruleId?: string; state?: AlarmEventState; limit?: number } = {},
) => {
  const parts: string[] = [];
  if (opts.ruleId) parts.push(`rule_id=${encodeURIComponent(opts.ruleId)}`);
  if (opts.state) parts.push(`state=${encodeURIComponent(opts.state)}`);
  parts.push(`limit=${opts.limit ?? 200}`);
  return jget<AlarmEvent[]>(
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/events?${parts.join("&")}`,
  );
};

export const fetchAlarmPins = (orgId: string, surface: AlarmSurface) =>
  jget<AlarmPin[]>(
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/pins/${surface}`,
  );

export const replaceAlarmPins = (
  orgId: string,
  surface: AlarmSurface,
  ruleIds: string[],
) =>
  jreq<AlarmPin[]>(
    "PUT",
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/pins/${surface}`,
    { ruleIds },
  );

export const fetchAlarmOverview = (orgId: string, surface: AlarmSurface) =>
  jget<AlarmOverview>(
    `/v1/organizations/${encodeURIComponent(orgId)}/alarms/overview/${surface}`,
  );
