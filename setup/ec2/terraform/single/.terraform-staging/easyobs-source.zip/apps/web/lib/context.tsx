"use client";

import { createContext, useContext, useMemo, useState } from "react";

/** Cross-page workspace context: window size, live refresh, saved search. */
export type WindowChoice = "1h" | "6h" | "24h" | "7d" | "custom";

export const WINDOW_HOURS: Record<Exclude<WindowChoice, "custom">, number> = {
  "1h": 1,
  "6h": 6,
  "24h": 24,
  "7d": 168,
};

/** Resolved time range to send with each API call. */
export type ResolvedRange =
  | { kind: "window"; windowHours: number }
  | { kind: "range"; fromIso: string; toIso: string };

export type WorkspaceState = {
  window: WindowChoice;
  /** Switch to one of the presets; clears the stored custom range. */
  setWindow: (v: Exclude<WindowChoice, "custom">) => void;
  /** Enter custom mode with an explicit ISO from / to pair. */
  setCustomRange: (fromIso: string, toIso: string) => void;
  customFrom: string | null;
  customTo: string | null;
  live: boolean;
  setLive: (v: boolean) => void;
  search: string;
  setSearch: (v: string) => void;
};

const Ctx = createContext<WorkspaceState | null>(null);

export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  const [window, setWindowRaw] = useState<WindowChoice>("24h");
  const [customFrom, setCustomFrom] = useState<string | null>(null);
  const [customTo, setCustomTo] = useState<string | null>(null);
  const [live, setLive] = useState(false);
  const [search, setSearch] = useState("");

  const setWindow = (v: Exclude<WindowChoice, "custom">) => {
    setWindowRaw(v);
    setCustomFrom(null);
    setCustomTo(null);
  };
  const setCustomRange = (fromIso: string, toIso: string) => {
    setCustomFrom(fromIso);
    setCustomTo(toIso);
    setWindowRaw("custom");
  };

  const value = useMemo<WorkspaceState>(
    () => ({
      window,
      setWindow,
      customFrom,
      customTo,
      setCustomRange,
      live,
      setLive,
      search,
      setSearch,
    }),
    [window, customFrom, customTo, live, search],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useWorkspace(): WorkspaceState {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useWorkspace must be used inside WorkspaceProvider");
  return ctx;
}

/**
 * Reduce the workspace time selector to one of two shapes the API understands:
 * either a rolling `window_hours` count, or an explicit `(from, to)` range.
 */
export function resolveRange(state: WorkspaceState): ResolvedRange {
  if (state.window === "custom" && state.customFrom && state.customTo) {
    return { kind: "range", fromIso: state.customFrom, toIso: state.customTo };
  }
  const preset = (state.window === "custom" ? "24h" : state.window) as Exclude<
    WindowChoice,
    "custom"
  >;
  return { kind: "window", windowHours: WINDOW_HOURS[preset] };
}

/**
 * A stable cache key for `useQuery`. Changes whenever the user switches preset
 * or edits the custom range — guarantees refetch without duplicated cache.
 */
export function rangeKey(state: WorkspaceState): string {
  const r = resolveRange(state);
  return r.kind === "window"
    ? `w:${r.windowHours}`
    : `r:${r.fromIso}|${r.toIso}`;
}

/**
 * Human-readable label for the active window — useful in page headers and
 * KPI meta lines. Preset modes render as `24h`; custom mode renders the
 * absolute start/end in **UTC** so it lines up with the timestamps the
 * server returns (which are also UTC).
 */
export function windowLabel(state: WorkspaceState): string {
  if (state.window !== "custom") return state.window;
  if (!state.customFrom || !state.customTo) return "custom";
  try {
    const fmt = new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      timeZone: "UTC",
    });
    return `${fmt.format(new Date(state.customFrom))} → ${fmt.format(
      new Date(state.customTo),
    )} UTC`;
  } catch {
    return "custom";
  }
}
