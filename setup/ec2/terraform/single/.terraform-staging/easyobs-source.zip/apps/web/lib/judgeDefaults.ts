/** Mirrors ``easyobs.eval.judge.defaults`` for profile editor placeholders. */

export const DEFAULT_JUDGE_SYSTEM_PROMPT =
  'You are an evaluation judge. Read the rubric and the trace excerpt. ' +
  'Reply with strict JSON: {"score": <0.0-1.0>, "verdict": "pass|warn|fail", ' +
  '"reason": "..."}.';

export const DEFAULT_JUDGE_USER_MESSAGE_TEMPLATE =
  "Evaluate using the rubric and trace context below. " +
  "Respond with strict JSON only matching: " +
  '{"score": <number 0-1>, "verdict": "pass"|"warn"|"fail", "reason": "<short>"}.\n\n' +
  "rubric_id: {rubric_id}\n\n" +
  "rubric:\n{rubric}\n\n" +
  "context_json:\n{context_json}\n";
