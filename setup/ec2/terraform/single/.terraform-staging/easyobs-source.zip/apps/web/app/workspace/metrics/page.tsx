"use client";

import { useQuery } from "@tanstack/react-query";
import { Donut, PercentileBars, Sparkline, StackedBars } from "@/components/charts";
import { fetchOverview } from "@/lib/api";
import { rangeKey, resolveRange, useWorkspace, windowLabel } from "@/lib/context";
import { fmtInt, fmtMs, fmtPct } from "@/lib/format";
import { useI18n } from "@/lib/i18n/context";

export default function MetricsPage() {
  const { t } = useI18n();
  const ws = useWorkspace();
  const { live } = ws;
  const range = resolveRange(ws);
  const rk = rangeKey(ws);
  const wLabel = windowLabel(ws);
  const q = useQuery({
    queryKey: ["overview", rk, "metrics"],
    queryFn: () => fetchOverview(range, 24),
    refetchInterval: live ? 5_000 : false,
  });

  const data = q.data;
  const series = data?.series;

  const axis = series
    ? (() => {
        const start = new Date(series.startedAt).getTime();
        const span = series.bucketSpanSec * 1000;
        return Array.from({ length: series.bucketCount }, (_, i) => {
          const d = new Date(start + i * span);
          return `${d.getUTCHours()}:${String(d.getUTCMinutes()).padStart(2, "0")}`;
        });
      })()
    : [];

  return (
    <>
      <div className="eo-page-head">
        <div>
          <h1 className="eo-page-title">{t("pages.metrics.title")}</h1>
          <p className="eo-page-lede">{t("pages.metrics.lede")}</p>
        </div>
        <div className="eo-page-meta">
          <span className="eo-tag">window: {wLabel}</span>
        </div>
      </div>

      {q.isLoading && <div className="eo-empty">Computing metrics…</div>}
      {q.isError && <div className="eo-empty">API unavailable</div>}

      {data && (
        <>
          <div className="eo-grid-4">
            {[
              { label: "P50", value: data.kpi.p50LatencyMs, tone: undefined },
              { label: "P90", value: data.kpi.p90LatencyMs, tone: undefined },
              { label: "P95", value: data.kpi.p95LatencyMs, tone: "warn" as const },
              { label: "P99", value: data.kpi.p99LatencyMs, tone: "err" as const },
            ].map((k) => (
              <article key={k.label} className="eo-kpi" data-tone={k.tone}>
                <span className="eo-kpi-label">Latency {k.label}</span>
                <strong className="eo-kpi-value">{fmtMs(k.value)}</strong>
                <div className="eo-kpi-spark" style={{ width: 100 }}>
                  <Sparkline values={series?.p95Ms ?? []} />
                </div>
              </article>
            ))}
          </div>

          <div className="eo-grid-2">
            <div className="eo-card">
              <div className="eo-card-h">
                <h3 className="eo-card-title">Volume over time</h3>
                <span className="eo-card-sub">total vs errors</span>
              </div>
              <StackedBars
                totals={series?.total ?? []}
                errors={series?.errors ?? []}
                labels={axis}
              />
            </div>
            <div className="eo-card">
              <div className="eo-card-h">
                <h3 className="eo-card-title">P95 latency trend</h3>
                <span className="eo-card-sub">per bucket</span>
              </div>
              <div style={{ padding: "10px 0" }}>
                <Sparkline values={series?.p95Ms ?? []} height={140} />
              </div>
              <PercentileBars
                values={[
                  { key: "P50", value: data.kpi.p50LatencyMs },
                  { key: "P90", value: data.kpi.p90LatencyMs },
                  { key: "P95", value: data.kpi.p95LatencyMs },
                  { key: "P99", value: data.kpi.p99LatencyMs },
                ]}
              />
            </div>
          </div>

          <div className="eo-grid-2">
            <div className="eo-card">
              <div className="eo-card-h">
                <h3 className="eo-card-title">Service reliability</h3>
                <span className="eo-card-sub">error rate by service</span>
              </div>
              <div className="eo-table-wrap">
                <table className="eo-table">
                  <thead>
                    <tr>
                      <th>Service</th>
                      <th>Requests</th>
                      <th>Errors</th>
                      <th>Error rate</th>
                      <th>P50 / P95</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.services.map((s) => (
                      <tr key={s.name}>
                        <td className="eo-td-name">{s.name}</td>
                        <td className="mono">{fmtInt(s.count)}</td>
                        <td className="mono">{fmtInt(s.errorCount)}</td>
                        <td>
                          <span
                            className="eo-bar-mini"
                            style={{ width: 70 }}
                          >
                            <i
                              style={{
                                width: `${Math.min(100, s.errorRate)}%`,
                                background: s.errorRate > 0 ? "#e3465e" : "#22c07a",
                              }}
                            />
                          </span>
                          <span className="mono">{fmtPct(s.errorRate)}</span>
                        </td>
                        <td className="mono">
                          {fmtMs(s.p50)} / {fmtMs(s.p95)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="eo-card">
              <div className="eo-card-h">
                <h3 className="eo-card-title">Status mix</h3>
              </div>
              <Donut
                slices={[
                  { label: "OK", value: data.statusMix.OK, color: "#22c07a" },
                  { label: "ERROR", value: data.statusMix.ERROR, color: "#e3465e" },
                  { label: "UNSET", value: data.statusMix.UNSET, color: "#c7d1de" },
                ]}
              />
              <div className="eo-divider" style={{ margin: "12px 0" }} />
              <div className="eo-card-sub" style={{ marginBottom: 6 }}>
                Duration distribution
              </div>
              <div className="eo-dist">
                {data.latencyBands.map((b) => {
                  const m = Math.max(1, ...data.latencyBands.map((x) => x.count));
                  const pct = Math.round((b.count / m) * 100);
                  return (
                    <div key={b.label} className="eo-dist-row">
                      <span>{b.label}</span>
                      <div className="eo-dist-bar">
                        <i style={{ width: `${pct}%` }} />
                      </div>
                      <span className="mono">{fmtInt(b.count)}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}
