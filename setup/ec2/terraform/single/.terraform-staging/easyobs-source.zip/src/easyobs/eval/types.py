"""Closed enums shared by the evaluation domain.

Defining them as ``StrEnum`` keeps the DB columns plain text (for SQLite
portability) while still giving the Python layer real validation.
"""

from __future__ import annotations

from enum import StrEnum


class EvaluatorKind(StrEnum):
    """Three families of evaluators correspond to the three columns in the
    Result Detail UI: deterministic rules (cheap, fast), LLM judges
    (expensive, opinionated), and human reviewers (slow, ground truth)."""

    RULE = "rule"
    JUDGE = "judge"
    HUMAN = "human"


class TriggerLane(StrEnum):
    """How the run started. The lane drives both UI badges and accounting:
    ``rule_auto`` runs are free; the three judge lanes contribute to the
    daily cost roll-up."""

    RULE_AUTO = "rule_auto"
    JUDGE_MANUAL = "judge_manual"
    JUDGE_SCHEDULE = "judge_schedule"
    JUDGE_REPLAY = "judge_replay"
    RULE_REPLAY = "rule_replay"


class ConsensusPolicy(StrEnum):
    SINGLE = "single"
    MAJORITY = "majority"
    UNANIMOUS = "unanimous"
    WEIGHTED = "weighted"


class Verdict(StrEnum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    UNSET = "unset"


class GoldenLayer(StrEnum):
    """Three layers reflecting where in the agent loop the example lives.
    L1 captures intent, L2 captures retrieval ground truth, L3 captures
    the final response."""

    L1 = "L1"
    L2 = "L2"
    L3 = "L3"


class SourceKind(StrEnum):
    """Where a golden item came from. Used by the UI to badge the row and
    by the curation service to decide whether the item starts in
    ``candidate`` or ``active`` status."""

    MANUAL = "manual"
    AUTO = "auto"
    TRACE_GT = "trace_gt"


class RunStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class CostExceedAction(StrEnum):
    BLOCK = "block"
    DOWNGRADE = "downgrade"
    NOTIFY = "notify"


class EvalRunMode(StrEnum):
    """How a manual evaluation run interprets subjects (trace-only, human
    labels, or golden-set-assisted). Agent HTTP replay is out-of-band:
    operators call the service, ingest traces, then pass ``trace_ids``."""

    TRACE = "trace"
    HUMAN_LABEL = "human_label"
    GOLDEN_GT = "golden_gt"
    GOLDEN_JUDGE = "golden_judge"


class JudgeRubricMode(StrEnum):
    """Whether ``judge_rubric_text`` replaces the auto-generated rubric or
    is appended after the default profile/evaluator summary lines."""

    APPEND = "append"
    REPLACE = "replace"
