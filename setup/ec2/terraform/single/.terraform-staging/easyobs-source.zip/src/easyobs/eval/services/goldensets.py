"""Golden-set authoring service.

Three entry points are exposed (matching the 02.design v2 doc):

1. **Manual** — operator authors a single item via the API. Items start in
   ``active`` because a human just typed them.
2. **Auto-discover** — sweep recent traces of a service and harvest the
   ones that pass a heuristic filter. Items land in ``candidate`` so a
   reviewer must promote them.
3. **Trace-GT** — operator labels a known trace as ground truth and the
   item is created in ``active`` (the trace was hand-picked).
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import async_sessionmaker

from easyobs.db.models import EvalGoldenItemRow, EvalGoldenSetRow
from easyobs.eval.services.dtos import GoldenItemDTO, GoldenSetDTO
from easyobs.eval.types import GoldenLayer, SourceKind


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _normalise_layer(value: str) -> str:
    if value not in {l.value for l in GoldenLayer}:
        raise ValueError(f"unsupported layer {value!r}")
    return value


def _normalise_source(value: str) -> str:
    if value not in {s.value for s in SourceKind}:
        return SourceKind.MANUAL.value
    return value


class GoldenSetService:
    def __init__(
        self,
        session_factory: async_sessionmaker,
        *,
        trace_query=None,
    ) -> None:
        """``trace_query`` is the existing :class:`TraceQueryService` and
        is required only for auto-discover / trace-GT flows. We accept it
        as a kw-arg so the unit tests can supply a stub."""
        self._sf = session_factory
        self._traces = trace_query

    # ------------------------------------------------------------------
    # Sets
    # ------------------------------------------------------------------

    async def list_sets(
        self, *, org_id: str, project_ids: list[str] | None
    ) -> list[GoldenSetDTO]:
        async with self._sf() as s:
            stmt = select(EvalGoldenSetRow).where(EvalGoldenSetRow.org_id == org_id)
            rows = (await s.execute(stmt.order_by(EvalGoldenSetRow.created_at))).scalars().all()
            if project_ids is not None:
                allowed = set(project_ids)
                rows = [r for r in rows if r.project_id is None or r.project_id in allowed]
            counts: dict[str, int] = {}
            if rows:
                counts_stmt = (
                    select(EvalGoldenItemRow.set_id, func.count())
                    .where(EvalGoldenItemRow.set_id.in_([r.id for r in rows]))
                    .group_by(EvalGoldenItemRow.set_id)
                )
                for set_id, c in (await s.execute(counts_stmt)).all():
                    counts[set_id] = int(c)
            return [_set_dto(r, counts.get(r.id, 0)) for r in rows]

    async def get_set(
        self, *, org_id: str, set_id: str, project_ids: list[str] | None
    ) -> GoldenSetDTO | None:
        async with self._sf() as s:
            row = await s.get(EvalGoldenSetRow, set_id)
            if row is None or row.org_id != org_id:
                return None
            if (
                project_ids is not None
                and row.project_id is not None
                and row.project_id not in project_ids
            ):
                return None
            count = (
                await s.execute(
                    select(func.count())
                    .select_from(EvalGoldenItemRow)
                    .where(EvalGoldenItemRow.set_id == set_id)
                )
            ).scalar() or 0
            return _set_dto(row, int(count))

    async def create_set(
        self,
        *,
        org_id: str,
        project_id: str | None,
        name: str,
        layer: str,
        description: str,
        actor: str | None,
    ) -> GoldenSetDTO:
        normalised_layer = _normalise_layer(layer)
        async with self._sf() as s:
            row = EvalGoldenSetRow(
                id=uuid.uuid4().hex,
                org_id=org_id,
                project_id=project_id,
                name=name,
                layer=normalised_layer,
                description=description,
                created_at=_now(),
                created_by=actor,
            )
            s.add(row)
            await s.commit()
            await s.refresh(row)
            return _set_dto(row, 0)

    async def delete_set(self, *, org_id: str, set_id: str) -> bool:
        async with self._sf() as s:
            row = await s.get(EvalGoldenSetRow, set_id)
            if row is None or row.org_id != org_id:
                return False
            await s.delete(row)
            await s.commit()
            return True

    # ------------------------------------------------------------------
    # Items
    # ------------------------------------------------------------------

    async def list_items(
        self,
        *,
        org_id: str,
        set_id: str,
        project_ids: list[str] | None,
        status: str | None = None,
        limit: int = 200,
    ) -> list[GoldenItemDTO]:
        async with self._sf() as s:
            base = await s.get(EvalGoldenSetRow, set_id)
            if base is None or base.org_id != org_id:
                return []
            if (
                project_ids is not None
                and base.project_id is not None
                and base.project_id not in project_ids
            ):
                return []
            stmt = select(EvalGoldenItemRow).where(EvalGoldenItemRow.set_id == set_id)
            if status:
                stmt = stmt.where(EvalGoldenItemRow.status == status)
            rows = (
                await s.execute(stmt.order_by(EvalGoldenItemRow.created_at.desc()).limit(limit))
            ).scalars().all()
            return [_item_dto(r) for r in rows]

    async def add_manual_item(
        self,
        *,
        org_id: str,
        set_id: str,
        payload: dict[str, Any],
        project_ids: list[str] | None,
        actor: str | None,
    ) -> GoldenItemDTO:
        return await self._insert_item(
            org_id=org_id,
            set_id=set_id,
            payload=payload,
            source_kind=SourceKind.MANUAL.value,
            status="active",
            source_trace_id=None,
            project_ids=project_ids,
            actor=actor,
        )

    async def add_from_trace(
        self,
        *,
        org_id: str,
        set_id: str,
        trace_id: str,
        labels: dict[str, Any],
        project_ids: list[str] | None,
        actor: str | None,
    ) -> GoldenItemDTO:
        """Trace-GT entry point. We hydrate the trace summary so the golden
        item carries enough context (query/response/expected docs) for the
        rule + judge layer to consume it later."""

        payload: dict[str, Any] = {**labels}
        if self._traces is not None:
            try:
                detail = await self._traces.trace_detail(
                    trace_id, allowed_service_ids=project_ids
                )
            except Exception:
                detail = None
            if detail:
                summary = detail.get("llmSummary") or {}
                payload.setdefault("query", summary.get("query"))
                payload.setdefault("response", summary.get("response"))
                payload.setdefault("session", summary.get("session"))
                payload.setdefault("user", summary.get("user"))
        return await self._insert_item(
            org_id=org_id,
            set_id=set_id,
            payload=payload,
            source_kind=SourceKind.TRACE_GT.value,
            status="active",
            source_trace_id=trace_id,
            project_ids=project_ids,
            actor=actor,
        )

    async def auto_discover(
        self,
        *,
        org_id: str,
        set_id: str,
        service_ids: list[str],
        sample_size: int,
        actor: str | None,
    ) -> list[GoldenItemDTO]:
        """Sweep recent traces and harvest the ones that look like good
        candidates (have both a query and a response). Items land in
        ``candidate`` so a reviewer must promote them before they are
        used by an evaluation run."""

        if self._traces is None:
            return []
        traces = await self._traces.list_traces(
            service_ids=service_ids,
            limit=max(sample_size * 2, 50),
            with_llm=True,
        )
        added: list[GoldenItemDTO] = []
        for trace in traces:
            if len(added) >= sample_size:
                break
            summary = trace.get("llmSummary") or {}
            query = summary.get("query") or trace.get("rootName")
            response = summary.get("response")
            if not query or not response:
                continue
            payload = {
                "query": query,
                "response": response,
                "session": summary.get("session"),
                "user": summary.get("user"),
            }
            try:
                item = await self._insert_item(
                    org_id=org_id,
                    set_id=set_id,
                    payload=payload,
                    source_kind=SourceKind.AUTO.value,
                    status="candidate",
                    source_trace_id=trace.get("traceId"),
                    project_ids=service_ids,
                    actor=actor,
                )
            except LookupError:
                break
            added.append(item)
        return added

    async def update_item_status(
        self,
        *,
        org_id: str,
        item_id: str,
        status: str,
        project_ids: list[str] | None,
    ) -> GoldenItemDTO | None:
        async with self._sf() as s:
            row = await s.get(EvalGoldenItemRow, item_id)
            if row is None or row.org_id != org_id:
                return None
            if (
                project_ids is not None
                and row.project_id is not None
                and row.project_id not in project_ids
            ):
                return None
            if status not in {"candidate", "active", "archived"}:
                raise ValueError("invalid status")
            row.status = status
            await s.commit()
            await s.refresh(row)
            return _item_dto(row)

    async def delete_item(
        self,
        *,
        org_id: str,
        item_id: str,
        project_ids: list[str] | None,
    ) -> bool:
        async with self._sf() as s:
            row = await s.get(EvalGoldenItemRow, item_id)
            if row is None or row.org_id != org_id:
                return False
            if (
                project_ids is not None
                and row.project_id is not None
                and row.project_id not in project_ids
            ):
                return False
            await s.delete(row)
            await s.commit()
            return True

    # ------------------------------------------------------------------
    # Internal: shared insert
    # ------------------------------------------------------------------

    async def _insert_item(
        self,
        *,
        org_id: str,
        set_id: str,
        payload: dict[str, Any],
        source_kind: str,
        status: str,
        source_trace_id: str | None,
        project_ids: list[str] | None,
        actor: str | None,
    ) -> GoldenItemDTO:
        async with self._sf() as s:
            base = await s.get(EvalGoldenSetRow, set_id)
            if base is None or base.org_id != org_id:
                raise LookupError("golden set not found")
            if (
                project_ids is not None
                and base.project_id is not None
                and base.project_id not in project_ids
            ):
                raise PermissionError("project access denied")
            row = EvalGoldenItemRow(
                id=uuid.uuid4().hex,
                set_id=set_id,
                org_id=org_id,
                project_id=base.project_id,
                layer=base.layer,
                source_kind=_normalise_source(source_kind),
                status=status,
                payload_json=json.dumps(payload, ensure_ascii=False, default=str),
                source_trace_id=source_trace_id,
                created_at=_now(),
                created_by=actor,
            )
            s.add(row)
            await s.commit()
            await s.refresh(row)
            return _item_dto(row)


def _set_dto(row: EvalGoldenSetRow, count: int) -> GoldenSetDTO:
    return GoldenSetDTO(
        id=row.id,
        org_id=row.org_id,
        project_id=row.project_id,
        name=row.name,
        layer=row.layer,
        description=row.description,
        item_count=count,
        created_at=row.created_at,
    )


def _item_dto(row: EvalGoldenItemRow) -> GoldenItemDTO:
    try:
        payload = json.loads(row.payload_json or "{}")
    except Exception:
        payload = {}
    return GoldenItemDTO(
        id=row.id,
        set_id=row.set_id,
        org_id=row.org_id,
        project_id=row.project_id,
        layer=row.layer,
        source_kind=row.source_kind,
        status=row.status,
        payload=payload,
        source_trace_id=row.source_trace_id,
        created_at=row.created_at,
    )
