"""HTTP layer (FastAPI routers)."""
