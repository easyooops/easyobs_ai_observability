from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

_engine = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def configure_engine(database_url: str) -> None:
    global _engine, _session_factory
    # SQLite: wait up to 30s for writers (ingest + concurrent auto-rule tasks).
    # Without this, ``database is locked`` is common under parallel OTLP exports.
    kwargs: dict = {"echo": False}
    if "sqlite" in database_url:
        kwargs["connect_args"] = {"timeout": 30.0}
    _engine = create_async_engine(database_url, **kwargs)
    _session_factory = async_sessionmaker(_engine, expire_on_commit=False)


async def init_db(metadata) -> None:
    assert _engine is not None
    async with _engine.begin() as conn:
        await conn.run_sync(metadata.create_all)
        try:
            if conn.engine.dialect.name == "sqlite":
                # Better read/write overlap when post-ingest hooks write eval rows.
                await conn.execute(text("PRAGMA journal_mode=WAL"))
                await conn.execute(text("PRAGMA busy_timeout=30000"))
        except Exception:
            pass
        await _ensure_eval_judge_connection_column(conn)
        await _ensure_eval_result_session_id_column(conn)
        await _ensure_eval_profile_judge_rubric_columns(conn)
        await _ensure_eval_profile_pack_columns(conn)
        await _ensure_eval_profile_dimension_locale_columns(conn)
        await _ensure_eval_improvement_pack_columns(conn)
        await _ensure_eval_run_mode_columns(conn)


async def _ensure_eval_judge_connection_column(conn) -> None:
    """SQLite ``create_all`` does not add new columns; ALTER once if missing."""
    try:
        dialect = conn.engine.dialect.name
    except Exception:
        dialect = ""
    if dialect != "sqlite":
        return
    try:
        await conn.execute(
            text(
                "ALTER TABLE eval_judge_model ADD COLUMN connection_config_json TEXT DEFAULT '{}'"
            )
        )
    except Exception:
        pass


async def _ensure_eval_result_session_id_column(conn) -> None:
    """Add ``session_id`` when upgrading older SQLite DBs."""
    try:
        dialect = conn.engine.dialect.name
    except Exception:
        dialect = ""
    if dialect != "sqlite":
        return
    try:
        await conn.execute(
            text("ALTER TABLE eval_result ADD COLUMN session_id VARCHAR(128)")
        )
    except Exception:
        pass


async def _ensure_eval_profile_judge_rubric_columns(conn) -> None:
    try:
        dialect = conn.engine.dialect.name
    except Exception:
        dialect = ""
    if dialect != "sqlite":
        return
    for stmt in (
        "ALTER TABLE eval_profile ADD COLUMN judge_rubric_text TEXT DEFAULT ''",
        "ALTER TABLE eval_profile ADD COLUMN judge_rubric_mode VARCHAR(16) DEFAULT 'append'",
        "ALTER TABLE eval_profile ADD COLUMN judge_system_prompt TEXT DEFAULT ''",
    ):
        try:
            await conn.execute(text(stmt))
        except Exception:
            pass


async def _ensure_eval_profile_dimension_locale_columns(conn) -> None:
    try:
        dialect = conn.engine.dialect.name
    except Exception:
        dialect = ""
    if dialect != "sqlite":
        return
    for stmt in (
        "ALTER TABLE eval_profile ADD COLUMN judge_dimension_prompts_json TEXT DEFAULT '{}'",
        "ALTER TABLE eval_profile ADD COLUMN improvement_content_locale VARCHAR(8) DEFAULT 'en'",
    ):
        try:
            await conn.execute(text(stmt))
        except Exception:
            pass


async def _ensure_eval_improvement_pack_columns(conn) -> None:
    try:
        dialect = conn.engine.dialect.name
    except Exception:
        dialect = ""
    if dialect != "sqlite":
        return
    for stmt in (
        "ALTER TABLE eval_improvement ADD COLUMN improvement_pack VARCHAR(64)",
        "ALTER TABLE eval_improvement ADD COLUMN improvement_content_locale VARCHAR(8)",
    ):
        try:
            await conn.execute(text(stmt))
        except Exception:
            pass


async def _ensure_eval_profile_pack_columns(conn) -> None:
    try:
        dialect = conn.engine.dialect.name
    except Exception:
        dialect = ""
    if dialect != "sqlite":
        return
    for stmt in (
        "ALTER TABLE eval_profile ADD COLUMN judge_user_message_template TEXT DEFAULT ''",
        "ALTER TABLE eval_profile ADD COLUMN improvement_pack VARCHAR(64) DEFAULT 'easyobs_standard'",
    ):
        try:
            await conn.execute(text(stmt))
        except Exception:
            pass


async def _ensure_eval_run_mode_columns(conn) -> None:
    try:
        dialect = conn.engine.dialect.name
    except Exception:
        dialect = ""
    if dialect != "sqlite":
        return
    for stmt in (
        "ALTER TABLE eval_run ADD COLUMN run_mode VARCHAR(24) DEFAULT 'trace'",
        "ALTER TABLE eval_run ADD COLUMN golden_set_id VARCHAR(36)",
        "ALTER TABLE eval_run ADD COLUMN run_context_json TEXT DEFAULT '{}'",
    ):
        try:
            await conn.execute(text(stmt))
        except Exception:
            pass


def session_scope() -> async_sessionmaker[AsyncSession]:
    assert _session_factory is not None
    return _session_factory
