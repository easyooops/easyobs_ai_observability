"""Judge provider abstraction + a deterministic mock implementation.

The mock is the **default** so the system stays useful in air-gapped /
demo deployments and so tests never reach out to a paid API. It produces
stable scores derived from a hash of the request payload, which means
running the same trace through the same model twice always returns the
same answer — a property the consensus tests rely on.

Real providers can be registered through :func:`register_provider`. The
``OpenAI`` adapter included here is opt-in: it only imports the SDK if the
operator actually configures it.
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger("easyobs.eval.judge")


@dataclass(frozen=True, slots=True)
class JudgeModelSpec:
    """Static description of one registered judge model.

    Pricing is captured per-model so the cost guard can project spend
    *before* the provider is ever called."""

    id: str
    provider: str
    model: str
    name: str
    weight: float = 1.0
    temperature: float = 0.0
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    # Non-secret hints: api_key_env, base_url, region, deployment, etc.
    connection: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class JudgeRequest:
    rubric_id: str
    prompt: str
    context: dict[str, Any] = field(default_factory=dict)
    max_tokens: int = 256
    system_prompt: str | None = None
    #: Full user message sent to the LLM. When ``None``, providers fall back to
    #: a JSON payload of rubric + context (legacy / tests).
    user_message: str | None = None


@dataclass(frozen=True, slots=True)
class JudgeResponse:
    score: float
    verdict: str
    reason: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    raw: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Provider base + registry
# ---------------------------------------------------------------------------


class JudgeProvider(ABC):
    name: str = "abstract"

    @abstractmethod
    async def evaluate(self, model: JudgeModelSpec, request: JudgeRequest) -> JudgeResponse:
        ...


_PROVIDERS: dict[str, JudgeProvider] = {}


def register_provider(provider: JudgeProvider) -> None:
    _PROVIDERS[provider.name] = provider


def get_provider(name: str) -> JudgeProvider | None:
    return _PROVIDERS.get(name)


# ---------------------------------------------------------------------------
# Mock provider — deterministic so tests are stable
# ---------------------------------------------------------------------------


class MockJudgeProvider(JudgeProvider):
    """Hash-based scoring that varies across models *and* across rubrics
    but is identical across runs of the same input. Useful as the
    deployable default and as a contract the OpenAI adapter must honour
    in tests."""

    name = "mock"

    async def evaluate(self, model: JudgeModelSpec, request: JudgeRequest) -> JudgeResponse:
        seed = (
            f"{model.id}|{request.rubric_id}|{request.prompt}|"
            f"{request.system_prompt or ''}|{request.user_message or ''}|"
            f"{json.dumps(request.context, sort_keys=True, default=str)}"
        )
        digest = hashlib.sha256(seed.encode("utf-8")).digest()
        # Map first 8 bytes to a [0, 1] float; rest informs reason text.
        n = int.from_bytes(digest[:8], "big") / float(1 << 64)
        # Skew slightly toward the high end so demos look realistic but
        # still surface failures.
        score = round(min(max(0.5 + (n - 0.5) * 1.4, 0.0), 1.0), 3)
        verdict = "pass" if score >= 0.7 else "warn" if score >= 0.4 else "fail"
        reason = _mock_reason(request.rubric_id, model.name, score, request.context)
        _um = request.user_message or ""
        in_tokens = max(64, (len(request.prompt) + len(_um)) // 4)
        out_tokens = max(32, int(80 + 60 * (1 - score)))
        cost = (
            in_tokens / 1000.0 * model.cost_per_1k_input
            + out_tokens / 1000.0 * model.cost_per_1k_output
        )
        return JudgeResponse(
            score=score,
            verdict=verdict,
            reason=reason,
            input_tokens=in_tokens,
            output_tokens=out_tokens,
            cost_usd=round(cost, 6),
            raw={"provider": "mock", "model_id": model.id},
        )


def _mock_reason(rubric: str, model: str, score: float, context: dict[str, Any]) -> str:
    """Stable, human-readable justification — useful when testing UI states."""
    if score >= 0.85:
        verdict = "Strong"
    elif score >= 0.7:
        verdict = "Acceptable"
    elif score >= 0.4:
        verdict = "Borderline"
    else:
        verdict = "Weak"
    snippet = (context.get("response") or context.get("query") or "")[:120].replace("\n", " ")
    return f"[{model}] {verdict} on {rubric}: {snippet or 'no excerpt available'}"


# ---------------------------------------------------------------------------
# Optional OpenAI provider — only imported when configured
# ---------------------------------------------------------------------------


class OpenAIJudgeProvider(JudgeProvider):
    """Thin adapter to OpenAI's chat completions API.

    The provider stays optional: if the SDK is missing or no API key is
    configured we degrade to the mock so demos keep working. We never
    raise during ``evaluate``; instead we log and return a low-confidence
    response so the calling run still completes."""

    name = "openai"

    def __init__(self, api_key_env: str = "OPENAI_API_KEY") -> None:
        self._api_key_env = api_key_env

    async def evaluate(self, model: JudgeModelSpec, request: JudgeRequest) -> JudgeResponse:
        key_env = str(model.connection.get("api_key_env") or self._api_key_env)
        api_key = os.environ.get(key_env)
        if not api_key:
            _log.warning(
                "openai provider missing api key (%s); falling back to mock",
                key_env,
            )
            return await MockJudgeProvider().evaluate(model, request)
        try:
            from openai import AsyncOpenAI  # type: ignore
        except Exception:
            _log.warning("openai sdk not installed; falling back to mock")
            return await MockJudgeProvider().evaluate(model, request)
        base_raw = model.connection.get("base_url")
        base_url = str(base_raw).strip() if base_raw else None
        client_kw: dict[str, str] = {"api_key": api_key}
        if base_url:
            client_kw["base_url"] = base_url
        client = AsyncOpenAI(**client_kw)
        from easyobs.eval.judge.defaults import DEFAULT_JUDGE_SYSTEM_PROMPT

        sys_prompt = (request.system_prompt or "").strip() or DEFAULT_JUDGE_SYSTEM_PROMPT
        if request.user_message is not None:
            user_payload = request.user_message
        else:
            user_payload = json.dumps(
                {
                    "rubric_id": request.rubric_id,
                    "rubric": request.prompt,
                    "context": request.context,
                },
                ensure_ascii=False,
                default=str,
            )
        try:
            resp = await client.chat.completions.create(
                model=model.model or model.id,
                temperature=model.temperature,
                max_tokens=request.max_tokens,
                messages=[
                    {"role": "system", "content": sys_prompt},
                    {"role": "user", "content": user_payload},
                ],
                response_format={"type": "json_object"},
            )
        except Exception as exc:
            _log.warning("openai judge failed: %s; falling back to mock", exc)
            return await MockJudgeProvider().evaluate(model, request)

        choice = (resp.choices or [None])[0]
        content = (choice.message.content if choice and choice.message else None) or "{}"
        try:
            parsed = json.loads(content)
        except Exception:
            parsed = {"score": 0.5, "verdict": "warn", "reason": "judge returned non-JSON"}
        usage = getattr(resp, "usage", None)
        in_tokens = int(getattr(usage, "prompt_tokens", 0) or 0)
        out_tokens = int(getattr(usage, "completion_tokens", 0) or 0)
        cost = (
            in_tokens / 1000.0 * model.cost_per_1k_input
            + out_tokens / 1000.0 * model.cost_per_1k_output
        )
        score = float(parsed.get("score") or 0.0)
        if math.isnan(score):
            score = 0.0
        score = max(0.0, min(1.0, score))
        verdict = str(parsed.get("verdict") or "warn")
        reason = str(parsed.get("reason") or "")
        return JudgeResponse(
            score=score,
            verdict=verdict,
            reason=reason[:400],
            input_tokens=in_tokens,
            output_tokens=out_tokens,
            cost_usd=round(cost, 6),
            raw={"provider": "openai", "model_id": model.id},
        )


class OnPremOpenAICompatibleProvider(OpenAIJudgeProvider):
    """vLLM / LiteLLM proxy / any OpenAI-compatible HTTP surface (air-gapped)."""

    name = "onprem_openai_compatible"

    async def evaluate(self, model: JudgeModelSpec, request: JudgeRequest) -> JudgeResponse:
        if not str(model.connection.get("base_url") or "").strip():
            _log.warning(
                "onprem_openai_compatible requires connection.base_url; using mock",
            )
            return await MockJudgeProvider().evaluate(model, request)
        return await OpenAIJudgeProvider.evaluate(self, model, request)


class AzureOpenAIJudgeProvider(JudgeProvider):
    """Placeholder: wire to Azure OpenAI SDK using connection fields."""

    name = "azure_openai"

    async def evaluate(self, model: JudgeModelSpec, request: JudgeRequest) -> JudgeResponse:
        return await MockJudgeProvider().evaluate(model, request)


class AliasMockJudgeProvider(JudgeProvider):
    """Named provider slot until a native SDK adapter is enabled."""

    __slots__ = ("_n",)

    def __init__(self, provider_name: str) -> None:
        self._n = provider_name

    @property
    def name(self) -> str:  # type: ignore[override]
        return self._n

    async def evaluate(self, model: JudgeModelSpec, request: JudgeRequest) -> JudgeResponse:
        return await MockJudgeProvider().evaluate(model, request)


register_provider(MockJudgeProvider())
register_provider(OpenAIJudgeProvider())
register_provider(OnPremOpenAICompatibleProvider())
register_provider(AzureOpenAIJudgeProvider())
for _alias in (
    "anthropic",
    "google_gemini",
    "aws_bedrock",
    "google_vertex",
):
    register_provider(AliasMockJudgeProvider(_alias))
