"""Multi-judge orchestrator.

Given a set of registered judge models and a profile-supplied rubric, the
runner fans out one provider call per model in parallel, then folds the
responses through the consensus aggregator. Cost guards are enforced
*before* the network round-trips so a misconfigured profile cannot quietly
burn an API budget.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

from easyobs.eval.judge.consensus import ConsensusOutcome, aggregate_consensus
from easyobs.eval.judge.providers import (
    JudgeModelSpec,
    JudgeRequest,
    JudgeResponse,
    get_provider,
)

_log = logging.getLogger("easyobs.eval.judge")


@dataclass(frozen=True, slots=True)
class JudgeOutcome:
    consensus: ConsensusOutcome
    per_model: list[dict[str, Any]]
    total_input_tokens: int
    total_output_tokens: int
    total_cost_usd: float
    judge_calls: int


def estimate_judge_cost(
    models: list[JudgeModelSpec],
    avg_prompt_chars: int = 1500,
    avg_response_tokens: int = 200,
) -> float:
    """Rough projection used by the cost guard *before* any HTTP call."""
    total = 0.0
    for m in models:
        in_tokens = max(64, avg_prompt_chars // 4)
        out_tokens = avg_response_tokens
        total += (
            in_tokens / 1000.0 * m.cost_per_1k_input
            + out_tokens / 1000.0 * m.cost_per_1k_output
        )
    return round(total, 6)


async def run_judges(
    *,
    models: list[JudgeModelSpec],
    request: JudgeRequest,
    consensus_policy: str,
) -> JudgeOutcome:
    if not models:
        return JudgeOutcome(
            consensus=ConsensusOutcome(
                score=0.0,
                verdict=__import__("easyobs.eval.types", fromlist=["Verdict"]).Verdict.UNSET,
                disagreement=0.0,
                agreement_ratio=0.0,
                reason="no judge models",
            ),
            per_model=[],
            total_input_tokens=0,
            total_output_tokens=0,
            total_cost_usd=0.0,
            judge_calls=0,
        )

    async def call_one(model: JudgeModelSpec) -> tuple[JudgeModelSpec, JudgeResponse]:
        provider = get_provider(model.provider) or get_provider("mock")
        assert provider is not None  # mock is always registered
        try:
            resp = await provider.evaluate(model, request)
        except Exception as exc:
            _log.exception(
                "judge provider failed; degrading", extra={"model": model.id}
            )
            from easyobs.eval.judge.providers import MockJudgeProvider

            resp = await MockJudgeProvider().evaluate(model, request)
            resp = JudgeResponse(
                score=resp.score,
                verdict=resp.verdict,
                reason=f"degraded ({exc.__class__.__name__}): {resp.reason}",
                input_tokens=resp.input_tokens,
                output_tokens=resp.output_tokens,
                cost_usd=resp.cost_usd,
                raw=resp.raw,
            )
        return model, resp

    pairs = await asyncio.gather(*(call_one(m) for m in models))
    consensus = aggregate_consensus(pairs, consensus_policy)
    per_model = [
        {
            "modelId": model.id,
            "modelName": model.name,
            "provider": model.provider,
            "score": resp.score,
            "verdict": resp.verdict,
            "reason": resp.reason,
            "inputTokens": resp.input_tokens,
            "outputTokens": resp.output_tokens,
            "costUsd": resp.cost_usd,
        }
        for model, resp in pairs
    ]
    in_tokens = sum(resp.input_tokens for _, resp in pairs)
    out_tokens = sum(resp.output_tokens for _, resp in pairs)
    cost = round(sum(resp.cost_usd for _, resp in pairs), 6)
    return JudgeOutcome(
        consensus=consensus,
        per_model=per_model,
        total_input_tokens=in_tokens,
        total_output_tokens=out_tokens,
        total_cost_usd=cost,
        judge_calls=len(pairs),
    )
